package com.energical.thermofloor

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var planView: PlanView
    private lateinit var status: TextView
    private var pdfRenderer: PdfRenderer? = null
    private var fileDescriptor: ParcelFileDescriptor? = null
    private var pageBitmap: Bitmap? = null
    private val pickPdf = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,246,248)) }
        val header = TextView(this).apply {
            text = "THERMOFLOOR  |  by Energical\nÉtude de chauffage au sol"
            textSize = 19f; setTextColor(Color.WHITE); setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(48,52,59))
        }
        root.addView(header)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(8,8,8,4) }
        actions.addView(makeButton("Importer PDF") { choosePdf() }, LinearLayout.LayoutParams(0, 52, 1f))
        actions.addView(makeButton("Effacer collecteur") { planView.clearCollector(); status.text = "Emplacement du collecteur non défini." }, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(actions)
        status = TextView(this).apply {
            text = "1. Importez un plan PDF.  2. Touchez le plan pour placer le collecteur."
            textSize = 14f; setTextColor(Color.DKGRAY); setPadding(14, 10, 14, 10)
        }
        root.addView(status)
        planView = PlanView(this) { x, y ->
            status.text = "Collecteur placé sur le plan (x=${"%.2f".format(x)}, y=${"%.2f".format(y)}). Vous pourrez le déplacer en touchant ailleurs."
        }
        root.addView(planView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val footer = TextView(this).apply {
            text = "Prototype V0.1 — import PDF et positionnement du collecteur. Le calcul hydraulique sera activé après calibration et reconnaissance des pièces."
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(14, 12, 14, 16)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply { text = label; textSize = 12f; setOnClickListener { action() } }

    private fun choosePdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
        }
        startActivityForResult(intent, pickPdf)
    }

    @Deprecated("Legacy callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickPdf || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try { loadPdf(uri) } catch (e: Exception) {
            Toast.makeText(this, "Impossible de lire ce PDF : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadPdf(uri: Uri) {
        pdfRenderer?.close(); fileDescriptor?.close()
        fileDescriptor = contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Fichier inaccessible")
        pdfRenderer = PdfRenderer(fileDescriptor!!)
        renderPage(0)
        status.text = "PDF chargé (${pdfRenderer!!.pageCount} page(s)). Touchez le plan pour placer le collecteur."
    }

    private fun renderPage(index: Int) {
        val renderer = pdfRenderer ?: return
        if (index !in 0 until renderer.pageCount) return
        renderer.openPage(index).use { page ->
            val scale = min(1800f / page.width, 2400f / page.height)
            val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            pageBitmap?.recycle(); pageBitmap = bmp; planView.setPlan(bmp)
        }
    }

    override fun onDestroy() {
        super.onDestroy(); pdfRenderer?.close(); fileDescriptor?.close(); pageBitmap?.recycle()
    }
}

private class PlanView(context: android.content.Context, val onCollector: (Float, Float) -> Unit) : View(context) {
    private var bitmap: Bitmap? = null
    private var collectorX = -1f
    private var collectorY = -1f
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(232,117,36); style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5f }
    private var imageRect = RectF()

    fun setPlan(bmp: Bitmap) { bitmap = bmp; invalidate() }
    fun clearCollector() { collectorX = -1f; collectorY = -1f; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(225,228,232))
        val bmp = bitmap ?: run {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 38f; textAlign = Paint.Align.CENTER }
            canvas.drawText("Importer un plan PDF", width / 2f, height / 2f, p); return
        }
        val scale = min(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val w = bmp.width * scale; val h = bmp.height * scale
        imageRect = RectF((width-w)/2, (height-h)/2, (width+w)/2, (height+h)/2)
        canvas.drawBitmap(bmp, null, imageRect, imagePaint)
        if (collectorX >= 0 && collectorY >= 0) {
            val x = imageRect.left + collectorX * imageRect.width(); val y = imageRect.top + collectorY * imageRect.height()
            canvas.drawCircle(x, y, 17f, markerPaint); canvas.drawCircle(x, y, 17f, ringPaint)
            val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(35,35,35); textSize = 28f; isFakeBoldText = true }
            canvas.drawText("COLLECTEUR", x + 24f, y - 18f, label)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN || bitmap == null || imageRect.width() <= 0) return true
        if (imageRect.contains(event.x, event.y)) {
            collectorX = ((event.x - imageRect.left) / imageRect.width()).coerceIn(0f, 1f)
            collectorY = ((event.y - imageRect.top) / imageRect.height()).coerceIn(0f, 1f)
            onCollector(collectorX, collectorY); invalidate()
        }
        return true
    }
}
