
package com.energical.thermofloor

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import java.util.Locale
import kotlin.math.min

class MainActivity : Activity() {

    private lateinit var planView: PlanView
    private lateinit var status: TextView
    private lateinit var results: TextView

    private lateinit var roomName: EditText
    private lateinit var floorArea: EditText
    private lateinit var height: EditText
    private lateinit var indoorTemp: EditText
    private lateinit var outdoorTemp: EditText
    private lateinit var airChanges: EditText
    private lateinit var heatedArea: EditText
    private lateinit var coveringResistance: EditText
    private lateinit var manifoldDistance: EditText
    private lateinit var pipeSpacing: EditText
    private lateinit var pipeDiameter: EditText
    private lateinit var waterDelta: EditText
    private lateinit var maxCircuitLength: EditText
    private lateinit var supplyTemp: EditText
    private lateinit var boundaryArea: EditText
    private lateinit var boundaryU: EditText
    private lateinit var adjacentTemp: EditText

    private var pdfRenderer: PdfRenderer? = null
    private var fileDescriptor: ParcelFileDescriptor? = null
    private var pageBitmap: Bitmap? = null

    private val pickPdf = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 246, 248))
        }

        val header = TextView(this).apply {
            text = "THERMOFLOOR | by Energical\nÉtude de chauffage au sol"
            textSize = 19f
            setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(48, 52, 59))
        }
        root.addView(header)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(6, 6, 6, 4)
        }

        actions.addView(
            makeButton("Importer PDF") { choosePdf() },
            LinearLayout.LayoutParams(0, 50, 1f)
        )

        actions.addView(
            makeButton("Effacer collecteur") {
                planView.clearCollector()
                status.text = "Emplacement du collecteur non défini."
            },
            LinearLayout.LayoutParams(0, 50, 1f)
        )

        root.addView(actions)

        status = TextView(this).apply {
            text = "Importez un plan PDF puis touchez le plan pour placer le collecteur."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(12, 8, 12, 8)
        }
        root.addView(status)

        planView = PlanView(this) { x, y ->
            status.text = String.format(
                Locale.FRANCE,
                "Collecteur placé : X = %.2f ; Y = %.2f",
                x,
                y
            )
        }

        root.addView(
            planView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(260)
            )
        )

        val formContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 12)
        }

        formContent.addView(sectionTitle("PARAMÈTRES DE LA PIÈCE"))

        roomName = addField(formContent, "Nom de la pièce", "Séjour", false)
        floorArea = addField(formContent, "Surface totale (m²)", "20")
        height = addField(formContent, "Hauteur sous plafond (m)", "2.70")
        indoorTemp = addField(formContent, "Température intérieure (°C)", "20")
        outdoorTemp = addField(formContent, "Température extérieure de calcul (°C)", "-5")
        airChanges = addField(formContent, "Renouvellement d'air (vol/h)", "0.6")
        heatedArea = addField(formContent, "Surface chauffable (m²)", "18")
        coveringResistance = addField(
            formContent,
            "Résistance thermique du revêtement (m².K/W)",
            "0.05"
        )

        formContent.addView(sectionTitle("PAROIS DE LA PIÈCE"))

        boundaryArea = addField(
            formContent,
            "Surface équivalente des parois (m²)",
            "20"
        )
        boundaryU = addField(
            formContent,
            "Coefficient U des parois (W/m².K)",
            "1.2"
        )
        adjacentTemp = addField(
            formContent,
            "Température de l'espace adjacent (°C)",
            "-5"
        )

        formContent.addView(sectionTitle("PARAMÈTRES HYDRAULIQUES"))

        manifoldDistance = addField(
            formContent,
            "Distance collecteur - pièce (m)",
            "5"
        )
        pipeSpacing = addField(
            formContent,
            "Entraxe des tubes (m)",
            "0.15"
        )
        pipeDiameter = addField(
            formContent,
            "Diamètre intérieur du tube (m)",
            "0.012"
        )
        waterDelta = addField(
            formContent,
            "Écart de température départ/retour (°C)",
            "5"
        )
        maxCircuitLength = addField(
            formContent,
            "Longueur maximale par circuit (m)",
            "100"
        )
        supplyTemp = addField(
            formContent,
            "Température de départ d'eau (°C)",
            "35"
        )

        val calculateButton = makeButton("LANCER LE CALCUL") {
            calculate()
        }.apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(232, 117, 36))
        }

        formContent.addView(
            calculateButton,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(12)
            }
        )

        formContent.addView(sectionTitle("RÉSULTATS"))

        results = TextView(this).apply {
            text = "Les résultats apparaîtront ici après le calcul."
            textSize = 14f
            setTextColor(Color.rgb(35, 35, 35))
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.WHITE)
        }

        formContent.addView(
            results,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(formContent)
        }

        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun sectionTitle(value: String): TextView {
        return TextView(this).apply {
            text = value
            textSize = 16f
            setTextColor(Color.rgb(48, 52, 59))
            setPadding(4, 16, 4, 8)
            paint.isFakeBoldText = true
        }
    }

    private fun addField(
        parent: LinearLayout,
        label: String,
        defaultValue: String,
        numeric: Boolean = true
    ): EditText {
        val title = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(2, 7, 2, 2)
        }
        parent.addView(title)

        val field = EditText(this).apply {
            setText(defaultValue)
            textSize = 15f
            setSingleLine(true)
            setPadding(10, 4, 10, 4)
            if (numeric) {
                inputType = InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    InputType.TYPE_NUMBER_FLAG_SIGNED
            } else {
                inputType = InputType.TYPE_CLASS_TEXT
            }
        }

        parent.addView(
            field,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )
        return field
    }

    private fun readNumber(field: EditText, label: String): Double {
        val value = field.text.toString().trim().replace(',', '.')
        return value.toDoubleOrNull()
            ?: throw IllegalArgumentException("Valeur invalide : $label")
    }

    private fun calculate() {
        if (!planView.hasCollector()) {
            Toast.makeText(
                this,
                "Placez d'abord le collecteur sur le plan.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            val room = HeatingCalculator.RoomInput(
                name = roomName.text.toString().trim(),
                floorAreaM2 = readNumber(floorArea, "surface totale"),
                clearHeightM = readNumber(height, "hauteur"),
                indoorTempC = readNumber(indoorTemp, "température intérieure"),
                designOutdoorTempC = readNumber(outdoorTemp, "température extérieure"),
                airChangesPerHour = readNumber(airChanges, "renouvellement d'air"),
                boundaries = listOf(
                    HeatingCalculator.Boundary(
                        name = "Parois équivalentes",
                        areaM2 = readNumber(boundaryArea, "surface des parois"),
                        uValueWm2K = readNumber(boundaryU, "coefficient U"),
                        adjacentTempC = readNumber(adjacentTemp, "température adjacente")
                    )
                ),
                heatedFloorAreaM2 = readNumber(heatedArea, "surface chauffable"),
                floorCoveringResistanceM2KW = readNumber(
                    coveringResistance,
                    "résistance du revêtement"
                ),
                manifoldDistanceM = readNumber(
                    manifoldDistance,
                    "distance collecteur"
                ),
                pipeSpacingM = readNumber(pipeSpacing, "entraxe"),
                pipeInnerDiameterM = readNumber(pipeDiameter, "diamètre intérieur"),
                waterDeltaTC = readNumber(waterDelta, "écart de température"),
                maxCircuitLengthM = readNumber(maxCircuitLength, "longueur maximale"),
                designSupplyTempC = readNumber(supplyTemp, "température de départ")
            )

            val result = HeatingCalculator.calculateRoom(room)

            if (!result.calculationValid) {
                results.text = "DONNÉES À CORRIGER\n\n" +
                    result.warnings.joinToString("\n• ", prefix = "• ")
                return
            }

            val report = StringBuilder()

            report.appendLine("RÉSULTATS : ${result.name}")
            report.appendLine()
            report.appendLine("DÉPERDITIONS THERMIQUES")
            report.appendLine(
                "Transmission : ${format(result.transmissionLossW)} W"
            )
            report.appendLine(
                "Ventilation : ${format(result.ventilationLossW)} W"
            )
            report.appendLine(
                "Puissance totale : ${format(result.totalHeatLossW)} W"
            )
            report.appendLine(
                "Déperdition spécifique : ${format(result.specificHeatLossWm2)} W/m²"
            )

            report.appendLine()
            report.appendLine("CAPACITÉ DU PLANCHER")
            report.appendLine(
                "Puissance indicative maximale : ${format(result.estimatedFloorOutputLimitW)} W"
            )
            report.appendLine(
                "Marge de puissance : ${format(result.outputMarginW)} W"
            )

            report.appendLine()
            report.appendLine("CIRCUITS")
            report.appendLine("Nombre de circuits : ${result.circuitCount}")

            result.circuits.forEach { circuit ->
                report.appendLine()
                report.appendLine("Circuit ${circuit.number}")
                report.appendLine(
                    "Surface : ${format(circuit.heatedAreaM2)} m²"
                )
                report.appendLine(
                    "Longueur estimée : ${format(circuit.estimatedLengthM)} m"
                )
                report.appendLine(
                    "Débit : ${format(circuit.flowLph)} L/h"
                )
                report.appendLine(
                    "Vitesse : ${format(circuit.velocityMs)} m/s"
                )
                report.appendLine(
                    "Perte de charge : ${format(circuit.pressureDropKPa)} kPa"
                )
            }

            report.appendLine()
            report.appendLine("AVERTISSEMENTS")
            result.warnings.forEach {
                report.appendLine("• $it")
            }

            report.appendLine()
            report.appendLine(
                "Résultat préliminaire : vérifier les données et valider " +
                    "le dimensionnement avec les tables certifiées du fabricant."
            )

            results.text = report.toString()

        } catch (e: Exception) {
            Toast.makeText(
                this,
                e.message ?: "Erreur pendant le calcul.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun format(value: Double): String {
        return String.format(Locale.FRANCE, "%.2f", value)
    }

    private fun makeButton(
        label: String,
        action: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            textSize = 12f
            setOnClickListener { action() }
        }
    }

    private fun choosePdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, pickPdf)
    }

    @Deprecated("Legacy callback kept for broad Android compatibility")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != pickPdf || resultCode != Activity.RESULT_OK) {
            return
        }

        val uri: Uri = data?.data ?: return

        try {
            loadPdf(uri)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Impossible de lire ce PDF : ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun loadPdf(uri: Uri) {
        pdfRenderer?.close()
        fileDescriptor?.close()

        fileDescriptor = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IOException("Fichier inaccessible")

        pdfRenderer = PdfRenderer(fileDescriptor!!)
        renderPage(0)

        status.text =
            "PDF chargé (${pdfRenderer!!.pageCount} page(s)). " +
                "Touchez le plan pour placer le collecteur."
    }

    private fun renderPage(index: Int) {
        val renderer = pdfRenderer ?: return

        if (index !in 0 until renderer.pageCount) return

        renderer.openPage(index).use { page ->
            val scale = min(
                1800f / page.width,
                2400f / page.height
            )

            val bitmapWidth = (page.width * scale).toInt().coerceAtLeast(1)
            val bitmapHeight = (page.height * scale).toInt().coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(
                bitmapWidth,
                bitmapHeight,
                Bitmap.Config.ARGB_8888
            )

            bitmap.eraseColor(Color.WHITE)

            page.render(
                bitmap,
                null,
                null,
                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
            )

            pageBitmap?.recycle()
            pageBitmap = bitmap
            planView.setPlan(bitmap)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        pdfRenderer?.close()
        fileDescriptor?.close()
        pageBitmap?.recycle()

        pdfRenderer = null
        fileDescriptor = null
        pageBitmap = null
    }

    private class PlanView(
        context: android.content.Context,
        private val onCollector: (Float, Float) -> Unit
    ) : View(context) {

        private var bitmap: Bitmap? = null
        private var collectorX = -1f
        private var collectorY = -1f

        private val imagePaint =
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        private val markerPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(232, 117, 36)
                style = Paint.Style.FILL
            }

        private val ringPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 5f
            }

        private var imageRect = RectF()

        fun setPlan(bmp: Bitmap) {
            bitmap = bmp
            invalidate()
        }

        fun hasCollector(): Boolean {
            return collectorX >= 0f && collectorY >= 0f
        }

        fun clearCollector() {
            collectorX = -1f
            collectorY = -1f
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(225, 228, 232))

            val bmp = bitmap ?: run {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.DKGRAY
                    textSize = 32f
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText(
                    "Importer un plan PDF",
                    width / 2f,
                    height / 2f,
                    paint
                )
                return
            }

            val scale = min(
                width.toFloat() / bmp.width,
                height.toFloat() / bmp.height
            )

            val imageWidth = bmp.width * scale
            val imageHeight = bmp.height * scale

            imageRect = RectF(
                (width - imageWidth) / 2f,
                (height - imageHeight) / 2f,
                (width + imageWidth) / 2f,
                (height + imageHeight) / 2f
            )

            canvas.drawBitmap(bmp, null, imageRect, imagePaint)

            if (hasCollector()) {
                val x = imageRect.left + collectorX * imageRect.width()
                val y = imageRect.top + collectorY * imageRect.height()

                canvas.drawCircle(x, y, 17f, markerPaint)
                canvas.drawCircle(x, y, 17f, ringPaint)

                val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(35, 35, 35)
                    textSize = 26f
                    isFakeBoldText = true
                }

                canvas.drawText(
                    "COLLECTEUR",
                    x + 24f,
                    y - 18f,
                    labelPaint
                )
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (
                event.action != MotionEvent.ACTION_DOWN ||
                bitmap == null ||
                imageRect.width() <= 0f
            ) {
                return true
            }

            if (imageRect.contains(event.x, event.y)) {
                collectorX = (
                    (event.x - imageRect.left) / imageRect.width()
                ).coerceIn(0f, 1f)

                collectorY = (
                    (event.y - imageRect.top) / imageRect.height()
                ).coerceIn(0f, 1f)

                onCollector(collectorX, collectorY)
                invalidate()
            }

            return true
        }
    }
}
