package com.energical.thermofloor

import kotlin.math.*

/**
 * THERMOFLOOR preliminary design engine.
 * SI units internally: m, m2, W, Pa, kg/m3, m/s.
 * This engine deliberately refuses to call a design compliant when required inputs are absent.
 */
object HeatingCalculator {
    data class Boundary(
        val name: String,
        val areaM2: Double,
        val uValueWm2K: Double,
        val adjacentTempC: Double
    )

    data class RoomInput(
        val name: String,
        val floorAreaM2: Double,
        val clearHeightM: Double,
        val indoorTempC: Double,
        val designOutdoorTempC: Double,
        val airChangesPerHour: Double,
        val boundaries: List<Boundary>,
        val heatedFloorAreaM2: Double,
        val floorCoveringResistanceM2KW: Double,
        val maxFloorSurfaceTempC: Double = 29.0,
        val manifoldDistanceM: Double,
        val pipeSpacingM: Double = 0.15,
        val pipeInnerDiameterM: Double = 0.012,
        val waterDeltaTC: Double = 5.0,
        val maxCircuitLengthM: Double = 100.0,
        val designSupplyTempC: Double = 35.0
    )

    data class CircuitResult(
        val number: Int,
        val heatedAreaM2: Double,
        val estimatedLengthM: Double,
        val flowLph: Double,
        val velocityMs: Double,
        val pressureDropKPa: Double
    )

    data class RoomResult(
        val name: String,
        val transmissionLossW: Double,
        val ventilationLossW: Double,
        val totalHeatLossW: Double,
        val specificHeatLossWm2: Double,
        val estimatedFloorOutputLimitW: Double,
        val outputMarginW: Double,
        val circuitCount: Int,
        val circuits: List<CircuitResult>,
        val warnings: List<String>,
        val calculationValid: Boolean
    )

    data class ProjectResult(val rooms: List<RoomResult>, val totalHeatLossW: Double, val warnings: List<String>)

    fun calculateRoom(r: RoomInput): RoomResult {
        val errors = validate(r)
        if (errors.isNotEmpty()) return RoomResult(r.name, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, emptyList(), errors, false)

        val dtIndoor = r.indoorTempC
        val transmission = r.boundaries.sumOf { it.uValueWm2K * it.areaM2 * (dtIndoor - it.adjacentTempC).coerceAtLeast(0.0) }
        val volume = r.floorAreaM2 * r.clearHeightM
        // 0.34 Wh/(m3.K) is the conventional air heat capacity factor for this simplified method.
        val ventilation = 0.34 * r.airChangesPerHour * volume * (dtIndoor - r.designOutdoorTempC).coerceAtLeast(0.0)
        val total = transmission + ventilation
        val specific = total / r.floorAreaM2

        // EN 1264 characteristic curve used only as a preliminary surface-temperature screening.
        // Certified output must be checked against the selected pipe/system manufacturer's tables.
        val deltaSurface = (r.maxFloorSurfaceTempC - r.indoorTempC).coerceAtLeast(0.0)
        val characteristicOutputWm2 = 8.92 * deltaSurface.pow(1.1)
        val coveringFactor = 1.0 / (1.0 + 8.92 * r.floorCoveringResistanceM2KW)
        val outputLimit = characteristicOutputWm2 * coveringFactor * r.heatedFloorAreaM2
        val margin = outputLimit - total
        val warnings = mutableListOf<String>()
        if (r.heatedFloorAreaM2 < r.floorAreaM2 * 0.75) warnings += "Moins de 75 % de la surface est chauffable : vérifier les zones périphériques et le mobilier fixe."
        if (margin < 0) warnings += "Puissance estimée du plancher insuffisante de ${"%.0f".format(-margin)} W : prévoir une réduction des déperditions ou un émetteur complémentaire."
        if (r.designSupplyTempC > 45.0) warnings += "Température de départ élevée pour un plancher chauffant : vérifier le générateur, la régulation et les limites du système."
        if (r.pipeSpacingM < 0.10 || r.pipeSpacingM > 0.30) warnings += "Entraxe inhabituel : confirmer avec l'étude thermique et le système retenu."
        if (r.floorCoveringResistanceM2KW > 0.15) warnings += "Résistance thermique du revêtement élevée : vérifier la puissance avec les tables certifiées du fabricant."

        val circuitResults = buildCircuits(r, total.coerceAtLeast(0.0))
        if (circuitResults.isEmpty()) warnings += "Impossible de créer des circuits avec la distance collecteur et la longueur maximale indiquées."
        if (circuitResults.any { it.velocityMs > 0.8 }) warnings += "Vitesse d'eau supérieure à 0,8 m/s dans au moins une boucle : vérifier diamètre et débit."
        if (circuitResults.any { it.pressureDropKPa > 30.0 }) warnings += "Perte de charge supérieure à 30 kPa dans au moins une boucle : vérifier le dimensionnement hydraulique."
        warnings += "Déperditions simplifiées : renseigner séparément les températures adjacentes de chaque paroi et les ponts thermiques pour une étude réglementaire."
        warnings += "Puissance du plancher indicative : confirmer selon EN 1264 et les données certifiées du fabricant (revêtement, pas, température moyenne d'eau)."

        return RoomResult(r.name, transmission, ventilation, total, specific, outputLimit, margin,
            circuitResults.size, circuitResults, warnings.distinct(), true)
    }

    fun calculateProject(rooms: List<RoomInput>): ProjectResult {
        val results = rooms.map(::calculateRoom)
        return ProjectResult(results, results.sumOf { it.totalHeatLossW }, results.flatMap { it.warnings }.distinct())
    }

    private fun buildCircuits(r: RoomInput, availableOutputW: Double): List<CircuitResult> {
        val areaPerCircuit = (r.maxCircuitLengthM - 2.0 * r.manifoldDistanceM).coerceAtLeast(0.0) * r.pipeSpacingM
        if (areaPerCircuit <= 0.0) return emptyList()
        val count = ceil(r.heatedFloorAreaM2 / areaPerCircuit).toInt().coerceAtLeast(1)
        val circuits = mutableListOf<CircuitResult>()
        var remaining = r.heatedFloorAreaM2
        val assignedOutput = availableOutputW / count
        repeat(count) { index ->
            val area = min(areaPerCircuit, remaining)
            if (area <= 0.0) return@repeat
            val length = area / r.pipeSpacingM + 2.0 * r.manifoldDistanceM
            val flowLph = if (r.waterDeltaTC > 0) assignedOutput / (1.163 * r.waterDeltaTC) else 0.0
            val flowM3s = flowLph / 3_600_000.0
            val areaPipe = PI * r.pipeInnerDiameterM * r.pipeInnerDiameterM / 4.0
            val velocity = if (areaPipe > 0) flowM3s / areaPipe else 0.0
            val rho = 992.0 // kg/m3, approximate water density around 40 C
            val mu = 0.000653 // Pa.s, approximate dynamic viscosity around 40 C
            val reynolds = if (mu > 0) rho * velocity * r.pipeInnerDiameterM / mu else 0.0
            val friction = when {
                reynolds <= 0.0 -> 0.0
                reynolds < 2300.0 -> 64.0 / reynolds
                else -> 0.25 / (ln(5.74 / reynolds.pow(0.9)).pow(2)) // Swamee-Jain, smooth-pipe approximation
            }
            val pressurePa = friction * (length / r.pipeInnerDiameterM) * (rho * velocity * velocity / 2.0)
            circuits += CircuitResult(index + 1, area, length, flowLph, velocity, pressurePa / 1000.0)
            remaining -= area
        }
        return circuits
    }

    private fun validate(r: RoomInput): List<String> {
        val e = mutableListOf<String>()
        if (r.name.isBlank()) e += "Nom de pièce obligatoire."
        if (r.floorAreaM2 <= 0 || r.clearHeightM <= 0 || r.heatedFloorAreaM2 <= 0) e += "Surfaces et hauteur doivent être positives."
        if (r.heatedFloorAreaM2 > r.floorAreaM2) e += "La surface chauffable ne peut pas dépasser la surface de la pièce."
        if (r.indoorTempC <= -20 || r.indoorTempC >= 40) e += "Température intérieure invalide."
        if (r.designOutdoorTempC >= r.indoorTempC || r.designOutdoorTempC < -40) e += "Température extérieure de base invalide."
        if (r.airChangesPerHour < 0 || r.airChangesPerHour > 5) e += "Taux de renouvellement d'air hors plage (0 à 5 vol/h)."
        if (r.boundaries.isEmpty()) e += "Ajouter les parois (murs, fenêtres, plafond/toiture et plancher) avec leurs surfaces, U et températures adjacentes."
        r.boundaries.forEach {
            if (it.areaM2 < 0 || it.uValueWm2K < 0 || it.adjacentTempC < -50 || it.adjacentTempC > 50) e += "Données invalides pour la paroi : ${it.name}."
        }
        if (r.floorCoveringResistanceM2KW < 0 || r.manifoldDistanceM < 0) e += "Résistance du revêtement et distance collecteur invalides."
        if (r.pipeSpacingM <= 0 || r.pipeInnerDiameterM <= 0 || r.waterDeltaTC <= 0 || r.maxCircuitLengthM <= 0) e += "Paramètres hydrauliques invalides."
        if (r.maxFloorSurfaceTempC <= r.indoorTempC) e += "La température maximale du sol doit dépasser la température intérieure."
        return e
    }
}
