
package com.energical.thermofloor

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.IOException
import java.util.Locale
import kotlin.math.*

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var planView: PlanView

    private var pdfRenderer: PdfRenderer? = null
    private var pdfDescriptor: ParcelFileDescriptor? = null
    private var planBitmap: Bitmap? = null

    private var lastResult: HeatingCalculator.RoomResult? = null
    private var selectedLayout = "Serpentin"
    private var selectedProfile = "Isolation moyenne"

    private val pickPdf = 1001
    private val savePdfRequest = 1002

    private lateinit var roomName: EditText
    private lateinit var ceilingHeight: EditText
    private lateinit var indoorTemp: EditText
    private lateinit var outdoorTemp: EditText
    private lateinit var coveringResistance: EditText
    private lateinit var manifoldDistance: EditText
    private lateinit var pipeSpacing: EditText
    private lateinit var pipeDiameter: EditText
    private lateinit var waterDelta: EditText
    private lateinit var maxCircuitLength: EditText
    private lateinit var supplyTemp: EditText
    private lateinit var manualCircuitCount: EditText

    private lateinit var profileSpinner: Spinner
    private lateinit var circuitModeSpinner: Spinner
    private lateinit var layoutSpinner: Spinner

    private var calibrated = false
    private var scaleMetersPerPixel = 0.0
    private var roomAreaM2 = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMainScreen()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun createRoot(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.rgb(245, 245, 245))
        }
    }

    private fun addTitle(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(45, 45, 45))
            setPadding(0, dp(12), 0, dp(12))
        })
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(10), 0, dp(4))
        })
    }

    private fun addField(
        parent: LinearLayout,
        label: String,
        value: String,
        numeric: Boolean = true
    ): EditText {
        addLabel(parent, label)

        val field = EditText(this).apply {
            setText(value)
            textSize = 16f
            setSingleLine(true)
            inputType = if (numeric) {
                InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    InputType.TYPE_NUMBER_FLAG_SIGNED
            } else {
                InputType.TYPE_CLASS_TEXT
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        parent.addView(field, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ))

        return field
    }

    private fun addButton(
        parent: LinearLayout,
        text: String,
        action: () -> Unit
    ) {
        parent.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(50)
        ).apply {
            topMargin = dp(7)
        })
    }

    private fun addSpinner(
        parent: LinearLayout,
        label: String,
        values: List<String>
    ): Spinner {
        addLabel(parent, label)

        val spinner = Spinner(this)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            values
        )
        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        spinner.adapter = adapter

        parent.addView(spinner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ))

        return spinner
    }

    private fun showMainScreen() {
        root = createRoot()

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addTitle(content, "THERMOFLOOR")
        addLabel(content, "Étude de plancher chauffant hydraulique")

        addButton(content, "IMPORTER LE PLAN PDF") {
            choosePdf()
        }

        planView = PlanView()
        content.addView(planView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(300)
        ).apply {
            topMargin = dp(10)
        })

        addLabel(
            content,
            "Importez le plan, calibrez son échelle puis tracez le contour de la pièce."
        )

        addButton(content, "1 - CALIBRER L'ÉCHELLE") {
            if (planBitmap == null) {
                message("Importez d'abord un plan PDF.")
            } else {
                planView.startCalibration()
                message("Touchez deux points éloignés sur le plan.")
            }
        }

        addButton(content, "2 - TRACER LE CONTOUR DE LA PIÈCE") {
            if (!calibrated) {
                message("Calibrez d'abord l'échelle du plan.")
            } else {
                planView.startRoomDrawing()
                message("Touchez les coins du contour de la pièce. Fermez le contour avec le bouton ci-dessous.")
            }
        }

        addButton(content, "FERMER LE CONTOUR ET CALCULER LA SURFACE") {
            val area = planView.finishRoom()
            if (area > 0.0) {
                roomAreaM2 = area
                message("Surface calculée : ${format(area)} m²")
            } else {
                message("Tracez au moins trois points et vérifiez l'échelle.")
            }
        }

        addButton(content, "ANNULER LE CONTOUR") {
            planView.clearRoom()
            roomAreaM2 = 0.0
        }

        addButton(content, "POSITIONNER LE COLLECTEUR") {
            planView.startCollector()
            message("Touchez le plan à l'emplacement du collecteur.")
        }

        addLabel(content, "Surface calculée à partir du plan")
        val areaDisplay = TextView(this).apply {
            text = "La surface sera affichée après le traçage."
            textSize = 17f
            setTextColor(Color.rgb(230, 115, 35))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        content.addView(areaDisplay)

        planView.onAreaChanged = { area ->
            roomAreaM2 = area
            areaDisplay.text = "Surface de la pièce : ${format(area)} m²"
        }

        addTitle(content, "DONNÉES DE LA PIÈCE")

        roomName = addField(content, "Nom de la pièce", "Pièce 1", false)
        ceilingHeight = addField(content, "Hauteur sous plafond (m)", "2.7")
        indoorTemp = addField(content, "Température intérieure (°C)", "20")
        outdoorTemp = addField(content, "Température extérieure de calcul (°C)", "-2")
        coveringResistance = addField(
            content,
            "Résistance thermique du revêtement (m².K/W)",
            "0.05"
        )

        addSpinner(
            content,
            "Profil d'isolation du bâtiment",
            listOf(
                "Isolation faible",
                "Isolation moyenne",
                "Bonne isolation"
            )
        ).also {
            profileSpinner = it
            it.setSelection(1)
        }

        addTitle(content, "PARAMÈTRES HYDRAULIQUES")

        manifoldDistance = addField(content, "Distance collecteur / pièce (m)", "5")
        pipeSpacing = addField(content, "Espacement des tubes (m)", "0.15")
        pipeDiameter = addField(content, "Diamètre intérieur du tube (m)", "0.012")
        waterDelta = addField(content, "Différence de température eau (°C)", "5")
        maxCircuitLength = addField(content, "Longueur maximale d'un circuit (m)", "100")
        supplyTemp = addField(content, "Température de départ d'eau (°C)", "35")

        addTitle(content, "CONFIGURATION DES CIRCUITS")

        layoutSpinner = addSpinner(
            content,
            "Disposition des tubes",
            listOf("Serpentin", "Spirale")
        )

        circuitModeSpinner = addSpinner(
            content,
            "Nombre de circuits",
            listOf("Automatique", "Manuel")
        )

        manualCircuitCount = addField(
            content,
            "Nombre de circuits souhaité",
            "2"
        )
        manualCircuitCount.visibility = View.GONE

        circuitModeSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    manualCircuitCount.visibility =
                        if (position == 1) View.VISIBLE else View.GONE
                }
            }

        addButton(content, "LANCER LE CALCUL") {
            calculate()
        }

        addLabel(content, "THERMOFLOOR by ENERGICAL")

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun number(field: EditText, label: String): Double {
        return field.text.toString()
            .trim()
            .replace(",", ".")
            .toDoubleOrNull()
            ?: throw IllegalArgumentException("Valeur incorrecte : $label")
    }

    private fun calculate() {
        try {
            if (!calibrated || roomAreaM2 <= 0.0) {
                throw IllegalArgumentException(
                    "Importez le plan, calibrez l'échelle et tracez la pièce."
                )
            }

            val modeManual = circuitModeSpinner.selectedItemPosition == 1

            val count = if (modeManual) {
                number(manualCircuitCount, "nombre de circuits").toInt()
            } else {
                null
            }

            if (count != null && count !in 1..50) {
                throw IllegalArgumentException(
                    "Le nombre de circuits doit être compris entre 1 et 50."
                )
            }

            selectedLayout = layoutSpinner.selectedItem.toString()
            selectedProfile = profileSpinner.selectedItem.toString()

            val input = HeatingCalculator.RoomInput(
                name = roomName.text.toString().ifBlank { "Pièce 1" },
                floorAreaM2 = roomAreaM2,
                clearHeightM = number(ceilingHeight, "hauteur"),
                indoorTempC = number(indoorTemp, "température intérieure"),
                designOutdoorTempC = number(outdoorTemp, "température extérieure"),
                airChangesPerHour = 0.6,
                boundaries = emptyList(),
                heatedFloorAreaM2 = roomAreaM2,
                floorCoveringResistanceM2KW =
                    number(coveringResistance, "résistance du revêtement"),
                manifoldDistanceM =
                    number(manifoldDistance, "distance collecteur"),
                pipeSpacingM = number(pipeSpacing, "espacement"),
                pipeInnerDiameterM = number(pipeDiameter, "diamètre intérieur"),
                waterDeltaTC = number(waterDelta, "différence de température"),
                maxCircuitLengthM =
                    number(maxCircuitLength, "longueur maximale"),
                designSupplyTempC =
                    number(supplyTemp, "température de départ"),
                manualCircuitCount = count,
                insulationProfile = selectedProfile
            )

            val result = HeatingCalculator.calculateRoom(input)

            if (!result.calculationValid) {
                throw IllegalArgumentException(result.warnings.joinToString("\n"))
            }

            lastResult = result
            planView.setCircuits(result.circuitCount)
            showResultsScreen(result)

        } catch (e: Exception) {
            message(e.message ?: "Erreur pendant le calcul.")
        }
    }

    private fun format(value: Double): String =
        String.format(Locale.FRANCE, "%.2f", value)

    private fun message(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    private fun showResultsScreen(result: HeatingCalculator.RoomResult) {
        val screen = createRoot()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addTitle(content, "RÉSULTATS DU CALCUL")

        addResultLine(content, "Pièce : ${result.name}")
        addResultLine(content, "Surface calculée : ${format(roomAreaM2)} m²")
        addResultLine(content, "Profil : $selectedProfile")
        addResultLine(content, "Déperditions : ${format(result.totalHeatLossW)} W")
        addResultLine(content, "Déperditions spécifiques : ${format(result.specificHeatLossWm2)} W/m²")
        addResultLine(content, "Puissance estimée du plancher : ${format(result.estimatedFloorOutputLimitW)} W")
        addResultLine(content, "Marge de puissance : ${format(result.outputMarginW)} W")

        addTitle(content, "CIRCUITS HYDRAULIQUES")

        addResultLine(content, "Disposition : $selectedLayout")
        addResultLine(content, "Nombre de circuits : ${result.circuitCount}")

        result.circuits.forEach { circuit ->
            addDivider(content)
            addResultLine(content, "Circuit ${circuit.number}")
            addResultLine(content, "Surface : ${format(circuit.heatedAreaM2)} m²")
            addResultLine(content, "Longueur estimée : ${format(circuit.estimatedLengthM)} m")
            addResultLine(content, "Débit : ${format(circuit.flowLph)} L/h")
            addResultLine(content, "Vitesse : ${format(circuit.velocityMs)} m/s")
            addResultLine(content, "Perte de charge : ${format(circuit.pressureDropKPa)} kPa")
        }

        if (result.warnings.isNotEmpty()) {
            addTitle(content, "AVERTISSEMENTS")
            result.warnings.forEach {
                addResultLine(content, "• $it")
            }
        }

        addButton(content, "TÉLÉCHARGER LE RAPPORT PDF") {
            createPdfFile()
        }

        addButton(content, "RETOUR AU PLAN") {
            showMainScreen()
        }

        scroll.addView(content)
        screen.addView(scroll)
        setContentView(screen)
    }

    private fun addResultLine(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(dp(8), dp(7), dp(8), dp(7))
        })
    }

    private fun addDivider(parent: LinearLayout) {
        parent.addView(View(this).apply {
            setBackgroundColor(Color.LTGRAY)
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(1)
        ))
    }

    private fun createPdfFile() {
        if (lastResult == null || planBitmap == null) {
            message("Aucun plan ou résultat disponible.")
            return
        }

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "THERMOFLOOR_Rapport.pdf")
        }

        startActivityForResult(intent, savePdfRequest)
    }

    private fun writePdf(uri: Uri) {
        val result = lastResult ?: return
        val document = PdfDocument()

        try {
            // Page 1 : plan et tracé des circuits.
            val pageInfo1 = PdfDocument.PageInfo.Builder(
                1190, 1684, 1
            ).create()

            val page1 = document.startPage(pageInfo1)
            val canvas1 = page1.canvas

            canvas1.drawColor(Color.WHITE)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(230, 115, 35)
                textSize = 34f
                typeface = Typeface.DEFAULT_BOLD
            }

            canvas1.drawText(
                "THERMOFLOOR by ENERGICAL",
                55f, 65f, titlePaint
            )

            val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 23f
            }

            canvas1.drawText(
                "PLAN DE PLANCHER CHAUFFANT",
                55f, 105f, subtitlePaint
            )

            val target = RectF(40f, 140f, 1150f, 1630f)
            val bitmap = planBitmap!!

            val ratio = minOf(
                target.width() / bitmap.width,
                target.height() / bitmap.height
            )

            val w = bitmap.width * ratio
            val h = bitmap.height * ratio

            val imageRect = RectF(
                target.centerX() - w / 2f,
                target.centerY() - h / 2f,
                target.centerX() + w / 2f,
                target.centerY() + h / 2f
            )

            val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas1.drawBitmap(bitmap, null, imageRect, imagePaint)

            // Les tracés sont dessinés sur le plan dans le PDF.
            val save = canvas1.save()
            canvas1.translate(imageRect.left, imageRect.top)
            canvas1.scale(
                imageRect.width() / planView.width.coerceAtLeast(1),
                imageRect.height() / planView.height.coerceAtLeast(1)
            )
            planView.drawCircuitOverlay(canvas1)
            canvas1.restoreToCount(save)

            document.finishPage(page1)

            // Page 2 : résultats et données hydrauliques.
            val pageInfo2 = PdfDocument.PageInfo.Builder(
                1190, 1684, 2
            ).create()

            val page2 = document.startPage(pageInfo2)
            val canvas2 = page2.canvas

            canvas2.drawColor(Color.WHITE)

            var y = 75f

            canvas2.drawText(
                "RAPPORT DE CALCUL",
                55f, y, titlePaint
            )
            y += 65f

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 22f
            }

            val lines = mutableListOf(
                "Pièce : ${result.name}",
                "Surface : ${format(roomAreaM2)} m²",
                "Profil d'isolation : $selectedProfile",
                "Déperditions totales : ${format(result.totalHeatLossW)} W",
                "Déperditions spécifiques : ${format(result.specificHeatLossWm2)} W/m²",
                "Puissance estimée du plancher : ${format(result.estimatedFloorOutputLimitW)} W",
                "Marge de puissance : ${format(result.outputMarginW)} W",
                "Disposition : $selectedLayout",
                "Nombre de circuits : ${result.circuitCount}",
                ""
            )

            result.circuits.forEach {
                lines += "CIRCUIT ${it.number}"
                lines += "Surface : ${format(it.heatedAreaM2)} m²"
                lines += "Longueur : ${format(it.estimatedLengthM)} m"
                lines += "Débit : ${format(it.flowLph)} L/h"
                lines += "Vitesse : ${format(it.velocityMs)} m/s"
                lines += "Perte de charge : ${format(it.pressureDropKPa)} kPa"
                lines += ""
            }

            if (result.warnings.isNotEmpty()) {
                lines += "AVERTISSEMENTS"
                lines.addAll(result.warnings.map { "- $it" })
            }

            lines += ""
            lines += "Calcul préliminaire : validation technique nécessaire."

            lines.forEach { line ->
                if (y > 1580f) return@forEach
                canvas2.drawText(line.take(100), 55f, y, textPaint)
                y += 31f
            }

            document.finishPage(page2)

            contentResolver.openOutputStream(uri)?.use {
                document.writeTo(it)
            } ?: throw IOException("Impossible d'enregistrer le PDF.")

            message("Rapport PDF enregistré.")

        } catch (e: Exception) {
            message("Erreur PDF : ${e.message}")
        } finally {
            document.close()
        }
    }

    private fun choosePdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, pickPdf)
    }

    @Deprecated("Legacy activity result API")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != Activity.RESULT_OK || data?.data == null) return

        when (requestCode) {
            pickPdf -> loadPdf(data.data!!)
            savePdfRequest -> writePdf(data.data!!)
        }
    }

    private fun loadPdf(uri: Uri) {
        try {
            closePdf()

            pdfDescriptor =
                contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IOException("Impossible d'ouvrir le PDF.")

            pdfRenderer = PdfRenderer(pdfDescriptor!!)
            renderPage()

            calibrated = false
            roomAreaM2 = 0.0

            message("Plan PDF importé. Calibrez son échelle.")

        } catch (e: Exception) {
            message("Erreur d'importation : ${e.message}")
        }
    }

    private fun renderPage() {
        val renderer = pdfRenderer ?: return
        if (renderer.pageCount == 0) return

        val page = renderer.openPage(0)

        try {
            // Résolution supérieure pour préserver les détails du plan.
            val scale = minOf(
                3200f / page.width,
                4200f / page.height
            )

            val width = (page.width * scale).toInt().coerceAtLeast(1)
            val height = (page.height * scale).toInt().coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
            )

            bitmap.eraseColor(Color.WHITE)

            page.render(
                bitmap,
                null,
                null,
                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
            )

            planBitmap?.recycle()
            planBitmap = bitmap

            planView.invalidate()

        } finally {
            page.close()
        }
    }

    private fun closePdf() {
        try {
            pdfRenderer?.close()
            pdfDescriptor?.close()
        } catch (_: Exception) {
        }

        pdfRenderer = null
        pdfDescriptor = null
    }

    override fun onDestroy() {
        closePdf()
        planBitmap?.recycle()
        planBitmap = null
        super.onDestroy()
    }

    private inner class PlanView : View(this@MainActivity) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        private var mode = "none"
        private var calibrationPoints = mutableListOf<PointF>()
        private var roomPoints = mutableListOf<PointF>()

        private var collector: PointF? = null
        private var circuitCount = 0

        var onAreaChanged: ((Double) -> Unit)? = null

        private fun imageRect(): RectF {
            val bitmap = planBitmap
                ?: return RectF(0f, 0f, width.toFloat(), height.toFloat())

            val ratio = minOf(
                width.toFloat() / bitmap.width,
                height.toFloat() / bitmap.height
            )

            val w = bitmap.width * ratio
            val h = bitmap.height * ratio

            return RectF(
                (width - w) / 2f,
                (height - h) / 2f,
                (width + w) / 2f,
                (height + h) / 2f
            )
        }

        private fun toBitmapPoint(x: Float, y: Float): PointF? {
            val bitmap = planBitmap ?: return null
            val rect = imageRect()

            if (!rect.contains(x, y)) return null

            return PointF(
                ((x - rect.left) / rect.width()) * bitmap.width,
                ((y - rect.top) / rect.height()) * bitmap.height
            )
        }

        private fun toViewPoint(p: PointF): PointF {
            val bitmap = planBitmap ?: return p
            val rect = imageRect()

            return PointF(
                rect.left + p.x / bitmap.width * rect.width(),
                rect.top + p.y / bitmap.height * rect.height()
            )
        }

        fun startCalibration() {
            mode = "calibration"
            calibrationPoints.clear()
            invalidate()
        }

        fun startRoomDrawing() {
            mode = "room"
            roomPoints.clear()
            invalidate()
        }

        fun startCollector() {
            mode = "collector"
        }

        fun clearRoom() {
            roomPoints.clear()
            mode = "none"
            onAreaChanged?.invoke(0.0)
            invalidate()
        }

        fun finishRoom(): Double {
            if (roomPoints.size < 3 || !calibrated) return 0.0

            val pixelArea = polygonArea(roomPoints)
            val area = pixelArea * scaleMetersPerPixel.pow(2)

            mode = "none"
            invalidate()
            onAreaChanged?.invoke(area)

            return area
        }

        fun setCircuits(count: Int) {
            circuitCount = count
            invalidate()
        }

        private fun polygonArea(points: List<PointF>): Double {
            var sum = 0.0

            for (i in points.indices) {
                val a = points[i]
                val b = points[(i + 1) % points.size]
                sum += a.x.toDouble() * b.y - b.x.toDouble() * a.y
            }

            return abs(sum) / 2.0
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.WHITE)

            val bitmap = planBitmap

            if (bitmap == null) {
                paint.color = Color.GRAY
                paint.textSize = 16f
                canvas.drawText(
                    "Importer un plan PDF",
                    dp(20).toFloat(),
                    height / 2f,
                    paint
                )
                return
            }

            val rect = imageRect()
            canvas.drawBitmap(bitmap, null, rect, paint)

            drawCircuitOverlay(canvas)

            if (calibrationPoints.isNotEmpty()) {
                paint.color = Color.BLUE
                paint.strokeWidth = dp(3).toFloat()

                calibrationPoints.forEach {
                    val p = toViewPoint(it)
                    canvas.drawCircle(p.x, p.y, dp(6).toFloat(), paint)
                }

                if (calibrationPoints.size == 2) {
                    val a = toViewPoint(calibrationPoints[0])
                    val b = toViewPoint(calibrationPoints[1])
                    canvas.drawLine(a.x, a.y, b.x, b.y, paint)
                }
            }
        }

        fun drawCircuitOverlay(canvas: Canvas) {
            val bitmap = planBitmap ?: return
            val rect = imageRect()

            // Contour de la pièce.
            if (roomPoints.size >= 2) {
                val path = Path()

                roomPoints.forEachIndexed { index, point ->
                    val p = toViewPoint(point)
                    if (index == 0) path.moveTo(p.x, p.y)
                    else path.lineTo(p.x, p.y)
                }

                if (mode != "room" && roomPoints.size >= 3) {
                    path.close()
                }

                paint.color = Color.rgb(30, 120, 220)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(2).toFloat()
                canvas.drawPath(path, paint)
                paint.style = Paint.Style.FILL
            }

            if (roomPoints.size >= 3 && circuitCount > 0) {
                val polygon = Path()

                roomPoints.forEachIndexed { index, point ->
                    val p = toViewPoint(point)
                    if (index == 0) polygon.moveTo(p.x, p.y)
                    else polygon.lineTo(p.x, p.y)
                }
                polygon.close()

                val save = canvas.save()
                canvas.clipPath(polygon)

                val bounds = RectF()
                polygon.computeBounds(bounds, true)

                val colors = intArrayOf(
                    Color.rgb(220, 45, 45),
                    Color.rgb(30, 90, 220),
                    Color.rgb(20, 150, 80),
                    Color.rgb(210, 120, 20),
                    Color.rgb(140, 60, 180)
                )

                val spacing = dp(12).toFloat().coerceAtLeast(8f)
                val circuitHeight = bounds.height() / circuitCount

                for (c in 0 until circuitCount) {
                    paint.color = colors[c % colors.size]
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = dp(2).toFloat()

                    val top = bounds.top + c * circuitHeight
                    val bottom = top + circuitHeight

                    val path = Path()
                    var y = top + spacing
                    var leftToRight = true
                    var first = true

                    while (y <= bottom) {
                        val startX = if (leftToRight) bounds.left else bounds.right
                        val endX = if (leftToRight) bounds.right else bounds.left

                        if (first) {
                            path.moveTo(startX, y)
                            first = false
                        } else {
                            path.lineTo(startX, y)
                        }

                        path.lineTo(endX, y)
                        y += spacing
                        leftToRight = !leftToRight
                    }

                    canvas.drawPath(path, paint)

                    paint.style = Paint.Style.FILL
                    paint.textSize = dp(12).toFloat()
                    canvas.drawText(
                        "C${c + 1}",
                        bounds.left + dp(5),
                        top + dp(15),
                        paint
                    )
                }

                canvas.restoreToCount(save)
            }

            // Collecteur.
            collector?.let {
                val p = toViewPoint(it)
                paint.color = Color.RED
                paint.style = Paint.Style.FILL
                canvas.drawCircle(p.x, p.y, dp(9).toFloat(), paint)

                paint.color = Color.WHITE
                paint.textSize = dp(10).toFloat()
                canvas.drawText("C", p.x - dp(3), p.y + dp(4), paint)
            }

            paint.style = Paint.Style.FILL
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_DOWN) return true

            val point = toBitmapPoint(event.x, event.y) ?: return true

            when (mode) {
                "calibration" -> {
                    calibrationPoints.add(point)

                    if (calibrationPoints.size == 2) {
                        askCalibrationLength()
                    }
                }

                "room" -> {
                    roomPoints.add(point)
                }

                "collector" -> {
                    collector = point
                    mode = "none"
                }
            }

            invalidate()
            return true
        }

        private fun askCalibrationLength() {
            val input = EditText(this@MainActivity).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL
                hint = "Longueur réelle en mètres"
            }

            AlertDialog.Builder(this@MainActivity)
                .setTitle("Calibration du plan")
                .setMessage("Entrez la distance réelle entre les deux points (en mètres).")
                .setView(input)
                .setPositiveButton("VALIDER") { _, _ ->
                    val length = input.text.toString()
                        .replace(",", ".")
                        .toDoubleOrNull()

                    val a = calibrationPoints[0]
                    val b = calibrationPoints[1]

                    val pixelDistance = hypot(
                        (b.x - a.x).toDouble(),
                        (b.y - a.y).toDouble()
                    )

                    if (length == null || length <= 0 || pixelDistance <= 0) {
                        calibrated = false
                        message("Longueur invalide. Recommencez la calibration.")
                    } else {
                        scaleMetersPerPixel = length / pixelDistance
                        calibrated = true
                        message("Échelle calibrée avec succès.")
                    }

                    mode = "none"
                    invalidate()
                }
                .setNegativeButton("ANNULER") { _, _ ->
                    calibrationPoints.clear()
                    mode = "none"
                    invalidate()
                }
                .show()
        }
    }
}
