# THERMOFLOOR — prototype Android V0.2 (moteur thermique initial)

Application Android native en Kotlin, destinée à l'étude de chauffage au sol hydraulique pour maisons individuelles.

## État du projet

### Interface existante
- Sélection d'un PDF depuis Android.
- Rendu de la première page.
- Positionnement/déplacement du repère de collecteur au toucher.

### Moteur de calcul ajouté (`HeatingCalculator.kt`)
- Modèle de données pièce/paroi.
- Déperditions par transmission : somme de U × surface × différence de température pour chaque paroi.
- Déperditions par renouvellement d'air : 0,34 × n × volume × différence entre température intérieure et extérieure de base.
- Puissance totale et puissance spécifique par pièce.
- Contrôle préliminaire de la puissance émissible du sol par une courbe caractéristique de type EN 1264, avec température de surface maximale et correction indicative du revêtement.
- Pré-dimensionnement des circuits à partir de la surface chauffée, de l'entraxe, de la distance au collecteur et de la longueur maximale.
- Estimation du débit par circuit à partir de la puissance affectée et du ΔT d'eau.
- Estimation de la vitesse et de la perte de charge linéaire par Darcy-Weisbach avec propriétés approximatives de l'eau.
- Alertes en cas de puissance insuffisante, longueur/vitesse/perte de charge à vérifier et données invalides.

## Limites importantes — ne pas utiliser comme plan d'exécution certifié

Cette V0.2 ajoute le moteur de calcul source, mais ne relie pas encore ce moteur à un formulaire de saisie dans l'interface. Elle ne détecte pas automatiquement les pièces dans les PDF, ne dessine pas encore les boucles sur le plan et ne génère pas de rapport PDF.

Le calcul de transmission dépend des surfaces, coefficients U et températures adjacentes saisis pour chaque paroi. Le calcul d'air est une approximation stationnaire et ne remplace pas une étude réglementaire détaillée (ponts thermiques, infiltrations, ventilation réelle, sol sur terre-plein, locaux non chauffés, etc.).

La puissance du plancher est un contrôle indicatif, pas une certification EN 1264. Le dimensionnement définitif doit utiliser les tables ou logiciels certifiés du fabricant, le revêtement exact, les températures moyennes d'eau, la construction du plancher et les limites de température de surface applicables. La perte de charge est une estimation de tube droit et ne couvre pas encore collecteur, raccords, vannes, générateur ni réseau primaire. L'équilibrage de pompe n'est pas encore implémenté.

Le plan PDF seul ne suffit jamais à établir des déperditions fiables. L'application devra demander et faire confirmer les données thermiques manquantes. Les résultats devront être contrôlés par un ingénieur thermicien/installateur qualifié avant exécution.

## Ouvrir le projet
- Ouvrir le dossier `THERMOFLOOR` dans Android Studio récent.
- Laisser Gradle synchroniser (Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35).
- Compiler via Build > Build Bundle(s) / APK(s) > Build APK(s).

## Prochaines étapes
1. Formulaire de saisie projet et pièces/parois avec validation.
2. Connexion de l'interface au moteur et tests unitaires sur cas de référence.
3. Calibration d'échelle PDF, gestion multi-pages et annotation des pièces.
4. Reconnaissance assistée des pièces et zones non chauffées, toujours avec validation humaine.
5. Génération géométrique des boucles (spirale/serpentin), raccordement aller/retour au collecteur choisi, rayon de courbure et contrôle des longueurs.
6. Calcul hydraulique complet avec pertes singulières, collecteur, vannes et sélection de pompe.
7. Rapport PDF détaillé et nomenclature.
