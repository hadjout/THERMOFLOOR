
package com.energical.thermofloor

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.IOException
import java.util.Locale
import kotlin.math.min

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var planImage: ImageView
    private lateinit var areaDisplay: TextView

    private var pdfRenderer: PdfRenderer? = null
    private var pdfDescriptor: ParcelFileDescriptor? = null
    private var planBitmap: Bitmap? = null

    private var lastResult: HeatingCalculator.RoomResult? = null

    private var recognizedDimensions = mutableListOf<Double>()
    private var selectedLengthM = 0.0
    private var selectedWidthM = 0.0
    private var roomAreaM2 = 0.0

    private var selectedLayout = "Serpentin"
    private var selectedProfile = "Isolation moyenne"

    private val pickPlanRequest = 1001
    private val savePdfRequest = 1002

    private lateinit var roomName: EditText
    private lateinit var ceilingHeight: EditText
    private lateinit var indoorTemp: EditText
    private lateinit var outdoorTemp: EditText
    private lateinit var coveringResistance: EditText
    private lateinit var manifoldDistance: EditText
    private lateinit var pipeSpacing: EditText
    private lateinit var pipeDiameter: EditText
    private lateinit var waterDelta: EditText
    private lateinit var maxCircuitLength: EditText
    private lateinit var supplyTemp: EditText
    private lateinit var manualCircuitCount: EditText

    private lateinit var profileSpinner: Spinner
    private lateinit var circuitModeSpinner: Spinner
    private lateinit var layoutSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMainScreen()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun createRoot(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.rgb(245, 245, 245))
        }
    }

    private fun addTitle(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(45, 45, 45))
            setPadding(0, dp(12), 0, dp(12))
        })
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(10), 0, dp(4))
        })
    }

    private fun addField(
        parent: LinearLayout,
        label: String,
        value: String,
        numeric: Boolean = true
    ): EditText {
        addLabel(parent, label)

        val field = EditText(this).apply {
            setText(value)
            textSize = 16f
            setSingleLine(true)
            inputType = if (numeric) {
                InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    InputType.TYPE_NUMBER_FLAG_SIGNED
            } else {
                InputType.TYPE_CLASS_TEXT
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        parent.addView(field, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ))

        return field
    }

    private fun addButton(
        parent: LinearLayout,
        text: String,
        action: () -> Unit
    ) {
        parent.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(50)
        ).apply {
            topMargin = dp(7)
        })
    }

    private fun addSpinner(
        parent: LinearLayout,
        label: String,
        values: List<String>
    ): Spinner {
        addLabel(parent, label)

        val spinner = Spinner(this)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            values
        )
        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        spinner.adapter = adapter

        parent.addView(spinner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ))

        return spinner
    }

    private fun showMainScreen() {
        root = createRoot()

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addTitle(content, "THERMOFLOOR")
        addLabel(content, "Étude de plancher chauffant hydraulique")

        addButton(content, "IMPORTER UN PLAN PDF / JPG / PNG") {
            choosePlan()
        }

        planImage = ImageView(this).apply {
            setBackgroundColor(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }

        content.addView(planImage, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(300)
        ).apply {
            topMargin = dp(10)
            bottomMargin = dp(8)
        })

        addLabel(
            content,
            "L'application lit les dimensions inscrites sur le plan. " +
                "Aucune échelle graphique n'est utilisée."
        )

        addButton(content, "ANALYSER LES DIMENSIONS DU PLAN") {
            analyzePlan()
        }

        addButton(content, "CHOISIR LA LONGUEUR ET LA LARGEUR RECONNUES") {
            chooseRoomDimensions()
        }

        areaDisplay = TextView(this).apply {
            text = "Importez un plan puis analysez ses dimensions."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(230, 115, 35))
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        content.addView(areaDisplay)

        addTitle(content, "DONNÉES DE LA PIÈCE")

        roomName = addField(content, "Nom de la pièce", "Pièce 1", false)
        ceilingHeight = addField(content, "Hauteur sous plafond (m)", "2.7")
        indoorTemp = addField(content, "Température intérieure (°C)", "20")
        outdoorTemp = addField(content, "Température extérieure de calcul (°C)", "-2")
        coveringResistance = addField(
            content,
            "Résistance thermique du revêtement (m².K/W)",
            "0.05"
        )

        profileSpinner = addSpinner(
            content,
            "Profil d'isolation du bâtiment",
            listOf(
                "Isolation faible",
                "Isolation moyenne",
                "Bonne isolation"
            )
        )
        profileSpinner.setSelection(1)

        addTitle(content, "PARAMÈTRES HYDRAULIQUES")

        manifoldDistance = addField(content, "Distance collecteur / pièce (m)", "5")
        pipeSpacing = addField(content, "Espacement des tubes (m)", "0.15")
        pipeDiameter = addField(content, "Diamètre intérieur du tube (m)", "0.012")
        waterDelta = addField(content, "Différence de température eau (°C)", "5")
        maxCircuitLength = addField(content, "Longueur maximale d'un circuit (m)", "100")
        supplyTemp = addField(content, "Température de départ d'eau (°C)", "35")

        addTitle(content, "CONFIGURATION DES CIRCUITS")

        layoutSpinner = addSpinner(
            content,
            "Disposition des tubes",
            listOf("Serpentin", "Spirale")
        )

        circuitModeSpinner = addSpinner(
            content,
            "Nombre de circuits",
            listOf("Automatique", "Manuel")
        )

        manualCircuitCount = addField(
            content,
            "Nombre de circuits souhaité",
            "2"
        )
        manualCircuitCount.visibility = View.GONE

        circuitModeSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    manualCircuitCount.visibility =
                        if (position == 1) View.VISIBLE else View.GONE
                }
            }

        addButton(content, "LANCER LE CALCUL") {
            calculate()
        }

        addLabel(content, "THERMOFLOOR by ENERGICAL")

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun choosePlan() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/pdf",
                    "image/jpeg",
                    "image/png"
                )
            )
        }

        startActivityForResult(intent, pickPlanRequest)
    }

    @Deprecated("Legacy activity result API")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != Activity.RESULT_OK || data?.data == null) return

        when (requestCode) {
            pickPlanRequest -> loadPlan(data.data!!)
            savePdfRequest -> writePdf(data.data!!)
        }
    }

    private fun loadPlan(uri: Uri) {
        try {
            closePdf()

            recognizedDimensions.clear()
            selectedLengthM = 0.0
            selectedWidthM = 0.0
            roomAreaM2 = 0.0
            lastResult = null

            val mime = contentResolver.getType(uri) ?: ""

            val bitmap = if (mime == "application/pdf" ||
                uri.toString().lowercase(Locale.ROOT).endsWith(".pdf")) {
                loadPdfFirstPage(uri)
            } else {
                loadImage(uri)
            }

            planBitmap?.recycle()
            planBitmap = bitmap
            planImage.setImageBitmap(bitmap)

            areaDisplay.text =
                "Plan importé. Lancez l'analyse OCR des dimensions."

            message("Plan importé. Analysez maintenant les dimensions.")

        } catch (e: Exception) {
            message("Erreur d'importation : ${e.message}")
        }
    }

    private fun loadPdfFirstPage(uri: Uri): Bitmap {
        pdfDescriptor =
            contentResolver.openFileDescriptor(uri, "r")
                ?: throw IOException("Impossible d'ouvrir le PDF.")

        pdfRenderer = PdfRenderer(pdfDescriptor!!)

        val renderer = pdfRenderer!!
        if (renderer.pageCount == 0) {
            throw IOException("Le PDF ne contient aucune page.")
        }

        val page = renderer.openPage(0)

        try {
            val scale = minOf(
                4000f / page.width,
                5000f / page.height
            )

            val width = (page.width * scale).toInt().coerceAtLeast(1)
            val height = (page.height * scale).toInt().coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
            )

            bitmap.eraseColor(Color.WHITE)

            page.render(
                bitmap,
                null,
                null,
                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
            )

            return bitmap
        } finally {
            page.close()
        }
    }

    private fun loadImage(uri: Uri): Bitmap {
        val original = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it)
        } ?: throw IOException("Impossible de lire l'image.")

        val maxWidth = 4000
        val maxHeight = 5000

        val ratio = minOf(
            1f,
            maxWidth.toFloat() / original.width,
            maxHeight.toFloat() / original.height
        )

        if (ratio >= 1f) return original

        val resized = Bitmap.createScaledBitmap(
            original,
            (original.width * ratio).toInt().coerceAtLeast(1),
            (original.height * ratio).toInt().coerceAtLeast(1),
            true
        )

        if (resized !== original) original.recycle()

        return resized
    }

    private fun analyzePlan() {
        val bitmap = planBitmap

        if (bitmap == null) {
            message("Importez d'abord un plan.")
            return
        }

        areaDisplay.text = "Analyse des dimensions en cours..."

        val recognizer = TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )

        val image = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val dimensions = extractDimensions(visionText.text)

                recognizedDimensions.clear()
                recognizedDimensions.addAll(dimensions)

                if (dimensions.size < 2) {
                    selectedLengthM = 0.0
                    selectedWidthM = 0.0
                    roomAreaM2 = 0.0

                    areaDisplay.text =
                        "Dimensions insuffisantes. Importez un plan plus clair " +
                            "avec les cotes et leurs unités visibles."

                    AlertDialog.Builder(this)
                        .setTitle("Plan non exploitable")
                        .setMessage(
                            "L'application n'a pas reconnu au moins deux " +
                                "dimensions avec leurs unités.\n\n" +
                                "Veuillez importer un plan plus net, complet " +
                                "et lisible. Aucune mesure ne sera inventée."
                        )
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    val list = dimensions.joinToString("\n") {
                        "• ${format(it)} m"
                    }

                    areaDisplay.text =
                        "Dimensions reconnues : ${dimensions.size}\n$list\n\n" +
                            "Sélectionnez la longueur et la largeur de la pièce."

                    AlertDialog.Builder(this)
                        .setTitle("Dimensions reconnues")
                        .setMessage(list)
                        .setPositiveButton("CHOISIR LES COTES") { _, _ ->
                            chooseRoomDimensions()
                        }
                        .setNegativeButton("FERMER", null)
                        .show()
                }
            }
            .addOnFailureListener { error ->
                areaDisplay.text =
                    "Échec de la lecture. Importez un plan plus clair."

                message("Erreur OCR : ${error.message}")
            }
            .addOnCompleteListener {
                recognizer.close()
            }
    }

    private fun extractDimensions(text: String): List<Double> {
        val regex = Regex(
            """(?i)(\d{1,4}(?:[.,]\d{1,3})?)\s*(mm|cm|m)\b"""
        )

        val result = mutableListOf<Double>()

        regex.findAll(text).forEach { match ->
            val number = match.groupValues[1]
                .replace(",", ".")
                .toDoubleOrNull() ?: return@forEach

            val unit = match.groupValues[2].lowercase(Locale.ROOT)

            val meters = when (unit) {
                "mm" -> number / 1000.0
                "cm" -> number / 100.0
                "m" -> number
                else -> return@forEach
            }

            if (meters in 0.10..100.0) {
                result.add(meters)
            }
        }

        return result
            .distinctBy { (it * 1000).toInt() }
            .sorted()
    }

    private fun chooseRoomDimensions() {
        if (recognizedDimensions.size < 2) {
            message("Analysez d'abord un plan contenant au moins deux cotes lisibles.")
            return
        }

        val labels = recognizedDimensions.map {
            "${format(it)} m"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Choisir la longueur de la pièce")
            .setItems(labels) { _, index ->
                selectedLengthM = recognizedDimensions[index]
                chooseWidth(index)
            }
            .setNegativeButton("ANNULER", null)
            .show()
    }

    private fun chooseWidth(lengthIndex: Int) {
        val available = recognizedDimensions.indices
            .filter { it != lengthIndex }

        val labels = available.map {
            "${format(recognizedDimensions[it])} m"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Choisir la largeur de la pièce")
            .setItems(labels) { _, selectedIndex ->
                selectedWidthM = recognizedDimensions[available[selectedIndex]]

                if (selectedLengthM <= 0.0 || selectedWidthM <= 0.0) {
                    message("Dimensions invalides. Recommencez.")
                    return@setItems
                }

                roomAreaM2 = selectedLengthM * selectedWidthM

                areaDisplay.text =
                    "Longueur : ${format(selectedLengthM)} m\n" +
                        "Largeur : ${format(selectedWidthM)} m\n" +
                        "Surface rectangulaire estimée : ${format(roomAreaM2)} m²"

                message(
                    "Dimensions sélectionnées. Vérifiez qu'elles correspondent " +
                        "bien à la même pièce."
                )
            }
            .setNegativeButton("ANNULER", null)
            .show()
    }

    private fun number(field: EditText, label: String): Double {
        return field.text.toString()
            .trim()
            .replace(",", ".")
            .toDoubleOrNull()
            ?: throw IllegalArgumentException("Valeur incorrecte : $label")
    }

    private fun calculate() {
        try {
            if (planBitmap == null) {
                throw IllegalArgumentException("Importez d'abord un plan.")
            }

            if (recognizedDimensions.size < 2 ||
                selectedLengthM <= 0.0 ||
                selectedWidthM <= 0.0 ||
                roomAreaM2 <= 0.0
            ) {
                throw IllegalArgumentException(
                    "Analysez le plan et sélectionnez les deux dimensions " +
                        "de la pièce avant le calcul."
                )
            }

            val modeManual = circuitModeSpinner.selectedItemPosition == 1

            val count = if (modeManual) {
                number(manualCircuitCount, "nombre de circuits").toInt()
            } else {
                null
            }

            if (count != null && count !in 1..50) {
                throw IllegalArgumentException(
                    "Le nombre de circuits doit être compris entre 1 et 50."
                )
            }

            selectedLayout = layoutSpinner.selectedItem.toString()
            selectedProfile = profileSpinner.selectedItem.toString()

            val input = HeatingCalculator.RoomInput(
                name = roomName.text.toString().ifBlank { "Pièce 1" },
                floorAreaM2 = roomAreaM2,
                clearHeightM = number(ceilingHeight, "hauteur"),
                indoorTempC = number(indoorTemp, "température intérieure"),
                designOutdoorTempC = number(outdoorTemp, "température extérieure"),
                airChangesPerHour = 0.6,
                boundaries = emptyList(),
                heatedFloorAreaM2 = roomAreaM2,
                floorCoveringResistanceM2KW =
                    number(coveringResistance, "résistance du revêtement"),
                manifoldDistanceM =
                    number(manifoldDistance, "distance collecteur"),
                pipeSpacingM = number(pipeSpacing, "espacement"),
                pipeInnerDiameterM = number(pipeDiameter, "diamètre intérieur"),
                waterDeltaTC = number(waterDelta, "différence de température"),
                maxCircuitLengthM =
                    number(maxCircuitLength, "longueur maximale"),
                designSupplyTempC =
                    number(supplyTemp, "température de départ"),
                manualCircuitCount = count,
                insulationProfile = selectedProfile
            )

            val result = HeatingCalculator.calculateRoom(input)

            if (!result.calculationValid) {
                throw IllegalArgumentException(
                    result.warnings.joinToString("\n")
                )
            }

            lastResult = result
            showResultsScreen(result)

        } catch (e: Exception) {
            message(e.message ?: "Erreur pendant le calcul.")
        }
    }

    private fun format(value: Double): String =
        String.format(Locale.FRANCE, "%.2f", value)

    private fun message(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    private fun showResultsScreen(result: HeatingCalculator.RoomResult) {
        val screen = createRoot()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addTitle(content, "RÉSULTATS DU CALCUL")

        addResultLine(content, "Pièce : ${result.name}")
        addResultLine(content, "Longueur reconnue : ${format(selectedLengthM)} m")
        addResultLine(content, "Largeur reconnue : ${format(selectedWidthM)} m")
        addResultLine(content, "Surface rectangulaire : ${format(roomAreaM2)} m²")
        addResultLine(content, "Profil : $selectedProfile")
        addResultLine(content, "Déperditions : ${format(result.totalHeatLossW)} W")
        addResultLine(content, "Déperditions spécifiques : ${format(result.specificHeatLossWm2)} W/m²")
        addResultLine(content, "Puissance estimée du plancher : ${format(result.estimatedFloorOutputLimitW)} W")
        addResultLine(content, "Marge de puissance : ${format(result.outputMarginW)} W")

        addTitle(content, "CIRCUITS HYDRAULIQUES")

        addResultLine(content, "Disposition : $selectedLayout")
        addResultLine(content, "Nombre de circuits : ${result.circuitCount}")

        result.circuits.forEach { circuit ->
            addDivider(content)
            addResultLine(content, "Circuit ${circuit.number}")
            addResultLine(content, "Surface : ${format(circuit.heatedAreaM2)} m²")
            addResultLine(content, "Longueur estimée : ${format(circuit.estimatedLengthM)} m")
            addResultLine(content, "Débit : ${format(circuit.flowLph)} L/h")
            addResultLine(content, "Vitesse : ${format(circuit.velocityMs)} m/s")
            addResultLine(content, "Perte de charge : ${format(circuit.pressureDropKPa)} kPa")
        }

        if (result.warnings.isNotEmpty()) {
            addTitle(content, "AVERTISSEMENTS")
            result.warnings.forEach {
                addResultLine(content, "• $it")
            }
        }

        addResultLine(
            content,
            "Attention : la surface est estimée par longueur × largeur. " +
                "Cette méthode convient à une pièce rectangulaire."
        )

        addButton(content, "TÉLÉCHARGER LE RAPPORT PDF") {
            createPdfFile()
        }

        addButton(content, "RETOUR AU PLAN") {
            showMainScreen()
            planBitmap?.let { planImage.setImageBitmap(it) }
            areaDisplay.text =
                "Longueur : ${format(selectedLengthM)} m\n" +
                    "Largeur : ${format(selectedWidthM)} m\n" +
                    "Surface : ${format(roomAreaM2)} m²"
        }

        scroll.addView(content)
        screen.addView(scroll)
        setContentView(screen)
    }

    private fun addResultLine(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(dp(8), dp(7), dp(8), dp(7))
        })
    }

    private fun addDivider(parent: LinearLayout) {
        parent.addView(View(this).apply {
            setBackgroundColor(Color.LTGRAY)
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(1)
        ))
    }

    private fun createPdfFile() {
        if (lastResult == null || planBitmap == null) {
            message("Aucun plan ou résultat disponible.")
            return
        }

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "THERMOFLOOR_Rapport.pdf")
        }

        startActivityForResult(intent, savePdfRequest)
    }

    private fun writePdf(uri: Uri) {
        val result = lastResult ?: return
        val bitmap = planBitmap ?: return
        val document = PdfDocument()

        try {
            val pageInfo1 = PdfDocument.PageInfo.Builder(
                1190, 1684, 1
            ).create()

            val page1 = document.startPage(pageInfo1)
            val canvas1 = page1.canvas

            canvas1.drawColor(Color.WHITE)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(230, 115, 35)
                textSize = 34f
                typeface = Typeface.DEFAULT_BOLD
            }

            val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 23f
            }

            canvas1.drawText(
                "THERMOFLOOR by ENERGICAL",
                55f, 65f, titlePaint
            )

            canvas1.drawText(
                "PLAN IMPORTÉ",
                55f, 105f, subtitlePaint
            )

            val target = RectF(40f, 140f, 1150f, 1630f)

            val ratio = minOf(
                target.width() / bitmap.width,
                target.height() / bitmap.height
            )

            val w = bitmap.width * ratio
            val h = bitmap.height * ratio

            val imageRect = RectF(
                target.centerX() - w / 2f,
                target.centerY() - h / 2f,
                target.centerX() + w / 2f,
                target.centerY() + h / 2f
            )

            canvas1.drawBitmap(
                bitmap,
                null,
                imageRect,
                Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            )

            document.finishPage(page1)

            val pageInfo2 = PdfDocument.PageInfo.Builder(
                1190, 1684, 2
            ).create()

            val page2 = document.startPage(pageInfo2)
            val canvas2 = page2.canvas

            canvas2.drawColor(Color.WHITE)

            var y = 75f

            canvas2.drawText(
                "RAPPORT DE CALCUL",
                55f, y, titlePaint
            )
            y += 65f

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 22f
            }

            val lines = mutableListOf(
                "Pièce : ${result.name}",
                "Longueur reconnue : ${format(selectedLengthM)} m",
                "Largeur reconnue : ${format(selectedWidthM)} m",
                "Surface rectangulaire : ${format(roomAreaM2)} m²",
                "Profil d'isolation : $selectedProfile",
                "Déperditions totales : ${format(result.totalHeatLossW)} W",
                "Déperditions spécifiques : ${format(result.specificHeatLossWm2)} W/m²",
                "Puissance estimée du plancher : ${format(result.estimatedFloorOutputLimitW)} W",
                "Marge de puissance : ${format(result.outputMarginW)} W",
                "Disposition : $selectedLayout",
                "Nombre de circuits : ${result.circuitCount}",
                ""
            )

            result.circuits.forEach {
                lines += "CIRCUIT ${it.number}"
                lines += "Surface : ${format(it.heatedAreaM2)} m²"
                lines += "Longueur : ${format(it.estimatedLengthM)} m"
                lines += "Débit : ${format(it.flowLph)} L/h"
                lines += "Vitesse : ${format(it.velocityMs)} m/s"
                lines += "Perte de charge : ${format(it.pressureDropKPa)} kPa"
                lines += ""
            }

            if (result.warnings.isNotEmpty()) {
                lines += "AVERTISSEMENTS"
                lines.addAll(result.warnings.map { "- $it" })
            }

            lines += ""
            lines += "Surface calculée par longueur × largeur."
            lines += "Calcul préliminaire : validation technique nécessaire."

            lines.forEach { line ->
                if (y <= 1580f) {
                    canvas2.drawText(line.take(100), 55f, y, textPaint)
                    y += 31f
                }
            }

            document.finishPage(page2)

            contentResolver.openOutputStream(uri)?.use {
                document.writeTo(it)
            } ?: throw IOException("Impossible d'enregistrer le PDF.")

            message("Rapport PDF enregistré.")

        } catch (e: Exception) {
            message("Erreur PDF : ${e.message}")
        } finally {
            document.close()
        }
    }

    private fun closePdf() {
        try {
            pdfRenderer?.close()
            pdfDescriptor?.close()
        } catch (_: Exception) {
        }

        pdfRenderer = null
        pdfDescriptor = null
    }

    override fun onDestroy() {
        closePdf()
        planBitmap?.recycle()
        planBitmap = null
        super.onDestroy()
    }
}
