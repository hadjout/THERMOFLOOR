
package com.energical.thermofloor

import kotlin.math.*

/**
 * THERMOFLOOR preliminary design engine.
 * SI units internally.
 * Preliminary calculations only: final design requires manufacturer data
 * and engineering validation.
 */
object HeatingCalculator {

    data class Boundary(
        val name: String,
        val areaM2: Double,
        val uValueWm2K: Double,
        val adjacentTempC: Double
    )

    data class RoomInput(
        val name: String,
        val floorAreaM2: Double,
        val clearHeightM: Double,
        val indoorTempC: Double,
        val designOutdoorTempC: Double,
        val airChangesPerHour: Double,
        val boundaries: List<Boundary>,
        val heatedFloorAreaM2: Double,
        val floorCoveringResistanceM2KW: Double,
        val maxFloorSurfaceTempC: Double = 29.0,
        val manifoldDistanceM: Double,
        val pipeSpacingM: Double = 0.15,
        val pipeInnerDiameterM: Double = 0.012,
        val waterDeltaTC: Double = 5.0,
        val maxCircuitLengthM: Double = 100.0,
        val designSupplyTempC: Double = 35.0,
        val manualCircuitCount: Int? = null
    )

    data class CircuitResult(
        val number: Int,
        val heatedAreaM2: Double,
        val estimatedLengthM: Double,
        val flowLph: Double,
        val velocityMs: Double,
        val pressureDropKPa: Double
    )

    data class RoomResult(
        val name: String,
        val transmissionLossW: Double,
        val ventilationLossW: Double,
        val totalHeatLossW: Double,
        val specificHeatLossWm2: Double,
        val estimatedFloorOutputLimitW: Double,
        val outputMarginW: Double,
        val circuitCount: Int,
        val circuits: List<CircuitResult>,
        val warnings: List<String>,
        val calculationValid: Boolean
    )

    data class ProjectResult(
        val rooms: List<RoomResult>,
        val totalHeatLossW: Double,
        val warnings: List<String>
    )

    fun calculateRoom(r: RoomInput): RoomResult {

        val errors = validate(r)

        if (errors.isNotEmpty()) {
            return RoomResult(
                r.name, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0, emptyList(), errors, false
            )
        }

        val transmission = r.boundaries.sumOf {
            it.uValueWm2K *
                it.areaM2 *
                (r.indoorTempC - it.adjacentTempC).coerceAtLeast(0.0)
        }

        val volume = r.floorAreaM2 * r.clearHeightM

        val ventilation =
            0.34 *
            r.airChangesPerHour *
            volume *
            (r.indoorTempC - r.designOutdoorTempC).coerceAtLeast(0.0)

        val total = transmission + ventilation
        val specific = total / r.floorAreaM2

        val deltaSurface =
            (r.maxFloorSurfaceTempC - r.indoorTempC).coerceAtLeast(0.0)

        val characteristicOutputWm2 =
            8.92 * deltaSurface.pow(1.1)

        val coveringFactor =
            1.0 / (1.0 + 8.92 * r.floorCoveringResistanceM2KW)

        val outputLimit =
            characteristicOutputWm2 *
            coveringFactor *
            r.heatedFloorAreaM2

        val margin = outputLimit - total

        val warnings = mutableListOf<String>()

        if (r.heatedFloorAreaM2 < r.floorAreaM2 * 0.75) {
            warnings += "Moins de 75 % de la surface est chauffable : vérifier les zones périphériques et le mobilier fixe."
        }

        if (margin < 0) {
            warnings += "Puissance estimée du plancher insuffisante de ${"%.0f".format(LocaleHolder.locale, -margin)} W : prévoir une réduction des déperditions ou un émetteur complémentaire."
        }

        if (r.designSupplyTempC > 45.0) {
            warnings += "Température de départ élevée : vérifier le générateur, la régulation et les limites du système."
        }

        if (r.pipeSpacingM < 0.10 || r.pipeSpacingM > 0.30) {
            warnings += "Entraxe inhabituel : confirmer avec l'étude thermique et le fabricant."
        }

        if (r.floorCoveringResistanceM2KW > 0.15) {
            warnings += "Résistance thermique du revêtement élevée : vérifier les tables certifiées du fabricant."
        }

        val circuits = buildCircuits(r, total.coerceAtLeast(0.0))

        if (circuits.isEmpty()) {
            warnings += "Impossible de créer des circuits avec les paramètres indiqués."
        }

        if (circuits.any { it.estimatedLengthM > r.maxCircuitLengthM }) {
            warnings += "Une ou plusieurs boucles dépassent la longueur maximale indiquée."
        }

        if (circuits.any { it.velocityMs > 0.8 }) {
            warnings += "Vitesse d'eau supérieure à 0,8 m/s dans au moins une boucle."
        }

        if (circuits.any { it.pressureDropKPa > 30.0 }) {
            warnings += "Perte de charge supérieure à 30 kPa dans au moins une boucle."
        }

        if (r.manualCircuitCount != null) {
            warnings += "Nombre de boucles imposé manuellement : vérifier les longueurs et les pertes de charge."
        }

        warnings += "Déperditions simplifiées : renseigner séparément les températures adjacentes de chaque paroi et les ponts thermiques pour une étude réglementaire."

        warnings += "Puissance indicative : confirmer selon EN 1264 et les données certifiées du fabricant."

        return RoomResult(
            r.name,
            transmission,
            ventilation,
            total,
            specific,
            outputLimit,
            margin,
            circuits.size,
            circuits,
            warnings.distinct(),
            true
        )
    }

    fun calculateProject(rooms: List<RoomInput>): ProjectResult {
        val results = rooms.map(::calculateRoom)

        return ProjectResult(
            results,
            results.sumOf { it.totalHeatLossW },
            results.flatMap { it.warnings }.distinct()
        )
    }

    private fun buildCircuits(
        r: RoomInput,
        availableOutputW: Double
    ): List<CircuitResult> {

        val availableLength =
            r.maxCircuitLengthM - 2.0 * r.manifoldDistanceM

        val areaPerCircuit =
            availableLength.coerceAtLeast(0.0) * r.pipeSpacingM

        if (areaPerCircuit <= 0.0) return emptyList()

        val automaticCount =
            ceil(r.heatedFloorAreaM2 / areaPerCircuit).toInt().coerceAtLeast(1)

        val count = r.manualCircuitCount ?: automaticCount

        if (count <= 0 || count > 50) return emptyList()

        val circuits = mutableListOf<CircuitResult>()

        val areaPerLoop = r.heatedFloorAreaM2 / count
        val outputPerLoop = availableOutputW / count

        repeat(count) { index ->

            val area = areaPerLoop

            val length =
                area / r.pipeSpacingM +
                2.0 * r.manifoldDistanceM

            val flowLph =
                outputPerLoop / (1.163 * r.waterDeltaTC)

            val flowM3s = flowLph / 3_600_000.0

            val pipeArea =
                PI * r.pipeInnerDiameterM * r.pipeInnerDiameterM / 4.0

            val velocity =
                if (pipeArea > 0.0) flowM3s / pipeArea else 0.0

            val rho = 992.0
            val mu = 0.000653

            val reynolds =
                if (mu > 0.0) {
                    rho * velocity * r.pipeInnerDiameterM / mu
                } else {
                    0.0
                }

            val friction = when {
                reynolds <= 0.0 -> 0.0
                reynolds < 2300.0 -> 64.0 / reynolds
                else -> 0.25 /
                    ln(5.74 / reynolds.pow(0.9)).pow(2)
            }

            val pressurePa =
                friction *
                (length / r.pipeInnerDiameterM) *
                (rho * velocity * velocity / 2.0)

            circuits += CircuitResult(
                index + 1,
                area,
                length,
                flowLph,
                velocity,
                pressurePa / 1000.0
            )
        }

        return circuits
    }

    private fun validate(r: RoomInput): List<String> {

        val errors = mutableListOf<String>()

        if (r.name.isBlank()) {
            errors += "Nom de pièce obligatoire."
        }

        if (
            r.floorAreaM2 <= 0 ||
            r.clearHeightM <= 0 ||
            r.heatedFloorAreaM2 <= 0
        ) {
            errors += "Surfaces et hauteur doivent être positives."
        }

        if (r.heatedFloorAreaM2 > r.floorAreaM2) {
            errors += "La surface chauffable ne peut pas dépasser la surface totale."
        }

        if (r.indoorTempC <= -20 || r.indoorTempC >= 40) {
            errors += "Température intérieure invalide."
        }

        if (
            r.designOutdoorTempC >= r.indoorTempC ||
            r.designOutdoorTempC < -40
        ) {
            errors += "Température extérieure de base invalide."
        }

        if (r.airChangesPerHour < 0 || r.airChangesPerHour > 5) {
            errors += "Taux de renouvellement d'air hors plage (0 à 5 vol/h)."
        }

        if (r.boundaries.isEmpty()) {
            errors += "Ajouter les parois avec leurs surfaces, coefficients U et températures adjacentes."
        }

        r.boundaries.forEach {
            if (
                it.areaM2 < 0 ||
                it.uValueWm2K < 0 ||
                it.adjacentTempC < -50 ||
                it.adjacentTempC > 50
            ) {
                errors += "Données invalides pour la paroi : ${it.name}."
            }
        }

        if (
            r.floorCoveringResistanceM2KW < 0 ||
            r.manifoldDistanceM < 0
        ) {
            errors += "Résistance du revêtement et distance collecteur invalides."
        }

        if (
            r.pipeSpacingM <= 0 ||
            r.pipeInnerDiameterM <= 0 ||
            r.waterDeltaTC <= 0 ||
            r.maxCircuitLengthM <= 0
        ) {
            errors += "Paramètres hydrauliques invalides."
        }

        if (
            r.manualCircuitCount != null &&
            r.manualCircuitCount !in 1..50
        ) {
            errors += "Le nombre manuel de boucles doit être compris entre 1 et 50."
        }

        if (r.maxFloorSurfaceTempC <= r.indoorTempC) {
            errors += "La température maximale du sol doit dépasser la température intérieure."
        }

        return errors
    }

    private object LocaleHolder {
        val locale = java.util.Locale.FRANCE
    }
}
