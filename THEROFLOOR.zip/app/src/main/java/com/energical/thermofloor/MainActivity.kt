
package com.energical.thermofloor

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var planView: PlanView

    private var pdfRenderer: PdfRenderer? = null
    private var pdfFileDescriptor: ParcelFileDescriptor? = null
    private var planBitmap: Bitmap? = null

    private var lastResult: HeatingCalculator.RoomResult? = null
    private var selectedLayout = "Automatique"

    private val pickPdf = 1001
    private val savePdfRequest = 1002

    private lateinit var roomName: EditText
    private lateinit var floorArea: EditText
    private lateinit var ceilingHeight: EditText
    private lateinit var indoorTemp: EditText
    private lateinit var outdoorTemp: EditText
    private lateinit var airChanges: EditText
    private lateinit var heatedArea: EditText
    private lateinit var coveringResistance: EditText
    private lateinit var manifoldDistance: EditText
    private lateinit var pipeSpacing: EditText
    private lateinit var pipeDiameter: EditText
    private lateinit var waterDelta: EditText
    private lateinit var maxCircuitLength: EditText
    private lateinit var supplyTemp: EditText
    private lateinit var manualCircuitCount: EditText

    private lateinit var circuitModeSpinner: Spinner
    private lateinit var layoutSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMainScreen()
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun createRoot(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.rgb(245, 245, 245))
        }
    }

    private fun addTitle(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 21f
            setTextColor(Color.rgb(45, 45, 45))
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        })
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(10), 0, dp(4))
        })
    }

    private fun addField(
        parent: LinearLayout,
        label: String,
        defaultValue: String,
        numeric: Boolean = true
    ): EditText {
        addLabel(parent, label)

        val field = EditText(this).apply {
            setText(defaultValue)
            textSize = 16f
            setSingleLine(true)
            inputType = if (numeric) {
                InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    InputType.TYPE_NUMBER_FLAG_SIGNED
            } else {
                InputType.TYPE_CLASS_TEXT
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        parent.addView(field, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ))

        return field
    }

    private fun addButton(
        parent: LinearLayout,
        text: String,
        action: () -> Unit
    ) {
        parent.addView(Button(this).apply {
            this.text = text
            textSize = 15f
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(52)
        ).apply {
            topMargin = dp(10)
        })
    }

    private fun addSpinner(
        parent: LinearLayout,
        label: String,
        values: List<String>
    ): Spinner {
        addLabel(parent, label)

        val spinner = Spinner(this)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            values
        )
        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        spinner.adapter = adapter

        parent.addView(spinner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ))

        return spinner
    }

    private fun showMainScreen() {
        root = createRoot()

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addTitle(content, "THERMOFLOOR")
        addLabel(content, "Étude de plancher chauffant hydraulique")

        addButton(content, "IMPORTER LE PLAN PDF") {
            choosePdf()
        }

        planView = PlanView()
        content.addView(planView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(260)
        ).apply {
            topMargin = dp(12)
            bottomMargin = dp(8)
        })

        addLabel(content, "Touchez le plan pour positionner le collecteur.")

        addButton(content, "EFFACER LA POSITION DU COLLECTEUR") {
            planView.clearCollector()
        }

        addTitle(content, "DONNÉES DE LA PIÈCE")

        roomName = addField(content, "Nom de la pièce", "Pièce 1", false)
        floorArea = addField(content, "Surface totale (m²)", "20")
        ceilingHeight = addField(content, "Hauteur sous plafond (m)", "2.7")
        indoorTemp = addField(content, "Température intérieure (°C)", "20")
        outdoorTemp = addField(content, "Température extérieure de calcul (°C)", "-2")
        airChanges = addField(content, "Renouvellement d'air (vol/h)", "0.5")
        heatedArea = addField(content, "Surface chauffée (m²)", "20")
        coveringResistance = addField(
            content,
            "Résistance thermique du revêtement (m².K/W)",
            "0.05"
        )

        addTitle(content, "PARAMÈTRES HYDRAULIQUES")

        manifoldDistance = addField(
            content,
            "Distance collecteur / pièce (m)",
            "5"
        )

        pipeSpacing = addField(
            content,
            "Espacement des tubes (m)",
            "0.15"
        )

        pipeDiameter = addField(
            content,
            "Diamètre intérieur du tube (m)",
            "0.012"
        )

        waterDelta = addField(
            content,
            "Différence de température eau (°C)",
            "5"
        )

        maxCircuitLength = addField(
            content,
            "Longueur maximale d'un circuit (m)",
            "100"
        )

        supplyTemp = addField(
            content,
            "Température de départ d'eau (°C)",
            "35"
        )

        addTitle(content, "CONFIGURATION DES CIRCUITS")

        layoutSpinner = addSpinner(
            content,
            "Disposition des tubes",
            listOf("Automatique", "Spirale", "Serpentin")
        )

        circuitModeSpinner = addSpinner(
            content,
            "Nombre de circuits",
            listOf("Automatique", "Manuel")
        )

        manualCircuitCount = addField(
            content,
            "Nombre de circuits souhaité",
            "2"
        )

        manualCircuitCount.visibility = View.GONE

        circuitModeSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    manualCircuitCount.visibility =
                        if (position == 1) View.VISIBLE else View.GONE
                }
            }

        addButton(content, "LANCER LE CALCUL") {
            calculate()
        }

        addLabel(content, "THERMOFLOOR by ENERGICAL")

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun number(field: EditText, label: String): Double {
        val value = field.text.toString().trim().replace(",", ".")
        return value.toDoubleOrNull()
            ?: throw IllegalArgumentException("Valeur incorrecte : $label")
    }

    private fun calculate() {
        try {
            val roomArea = number(floorArea, "surface totale")
            val heated = number(heatedArea, "surface chauffée")

            val modeManual = circuitModeSpinner.selectedItemPosition == 1

            val circuitCount = if (modeManual) {
                val count = number(manualCircuitCount, "nombre de circuits").toInt()
                if (count !in 1..50) {
                    throw IllegalArgumentException(
                        "Le nombre de circuits doit être compris entre 1 et 50."
                    )
                }
                count
            } else {
                null
            }

            if (roomArea <= 0 || heated <= 0 || heated > roomArea) {
                throw IllegalArgumentException(
                    "Vérifiez les surfaces de la pièce et de la zone chauffée."
                )
            }

            selectedLayout = layoutSpinner.selectedItem.toString()

            val input = HeatingCalculator.RoomInput(
                name = roomName.text.toString().ifBlank { "Pièce 1" },
                floorAreaM2 = roomArea,
                clearHeightM = number(ceilingHeight, "hauteur"),
                indoorTempC = number(indoorTemp, "température intérieure"),
                designOutdoorTempC = number(outdoorTemp, "température extérieure"),
                airChangesPerHour = number(airChanges, "renouvellement d'air"),
                boundaries = emptyList(),
                heatedFloorAreaM2 = heated,
                floorCoveringResistanceM2KW = number(
                    coveringResistance,
                    "résistance du revêtement"
                ),
                manifoldDistanceM = number(manifoldDistance, "distance collecteur"),
                pipeSpacingM = number(pipeSpacing, "espacement"),
                pipeInnerDiameterM = number(pipeDiameter, "diamètre intérieur"),
                waterDeltaTC = number(waterDelta, "différence de température"),
                maxCircuitLengthM = number(maxCircuitLength, "longueur maximale"),
                designSupplyTempC = number(supplyTemp, "température de départ"),
                manualCircuitCount = circuitCount
            )

            val result = HeatingCalculator.calculateRoom(input)
            lastResult = result
            showResultsScreen(result)

        } catch (e: Exception) {
            Toast.makeText(
                this,
                e.message ?: "Erreur pendant le calcul",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun format(value: Double): String {
        return String.format(Locale.FRANCE, "%.2f", value)
    }

    private fun showResultsScreen(result: HeatingCalculator.RoomResult) {
        val screen = createRoot()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        addTitle(content, "RÉSULTATS DU CALCUL")

        addResultLine(content, "Pièce : ${result.name}")
        addResultLine(
            content,
            "Pertes par transmission : ${format(result.transmissionLossW)} W"
        )
        addResultLine(
            content,
            "Pertes par ventilation : ${format(result.ventilationLossW)} W"
        )
        addResultLine(
            content,
            "Déperditions totales : ${format(result.totalHeatLossW)} W"
        )
        addResultLine(
            content,
            "Déperditions spécifiques : ${format(result.specificHeatLossWm2)} W/m²"
        )
        addResultLine(
            content,
            "Puissance estimée du plancher : ${format(result.estimatedFloorOutputLimitW)} W"
        )
        addResultLine(
            content,
            "Marge de puissance : ${format(result.outputMarginW)} W"
        )

        addTitle(content, "CIRCUITS HYDRAULIQUES")

        addResultLine(content, "Disposition choisie : $selectedLayout")
        addResultLine(content, "Nombre de circuits : ${result.circuitCount}")

        result.circuits.forEach { circuit ->
            addResultLine(content, "Circuit ${circuit.number}")
            addResultLine(
                content,
                "Surface chauffée : ${format(circuit.heatedAreaM2)} m²"
            )
            addResultLine(
                content,
                "Longueur estimée : ${format(circuit.estimatedLengthM)} m"
            )
            addResultLine(
                content,
                "Débit : ${format(circuit.flowLph)} L/h"
            )
            addResultLine(
                content,
                "Vitesse : ${format(circuit.velocityMs)} m/s"
            )
            addResultLine(
                content,
                "Perte de charge : ${format(circuit.pressureDropKPa)} kPa"
            )
            addDivider(content)
        }

        if (result.warnings.isNotEmpty()) {
            addTitle(content, "AVERTISSEMENTS")
            result.warnings.forEach {
                addResultLine(content, "• $it")
            }
        }

        addTitle(content, "INFORMATIONS")
        addResultLine(
            content,
            "Le calcul est préliminaire. Les limites de débit, de température, " +
                "de pression et les données fabricant doivent être vérifiées."
        )
        addResultLine(
            content,
            "Le tracé géométrique des tubes sur le plan et la détection automatique " +
                "des pièces ne sont pas encore activés dans cette version."
        )

        addButton(content, "TÉLÉCHARGER LE RAPPORT PDF") {
            createPdfFile()
        }

        addButton(content, "RETOUR AU PLAN ET AUX PARAMÈTRES") {
            showMainScreen()
        }

        scroll.addView(content)
        screen.addView(scroll)
        setContentView(screen)
    }

    private fun addResultLine(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.rgb(45, 45, 45))
            setPadding(dp(8), dp(7), dp(8), dp(7))
        })
    }

    private fun addDivider(parent: LinearLayout) {
        val line = View(this).apply {
            setBackgroundColor(Color.LTGRAY)
        }
        parent.addView(line, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(1)
        ).apply {
            topMargin = dp(5)
            bottomMargin = dp(5)
        })
    }

    private fun createPdfFile() {
        if (lastResult == null) {
            Toast.makeText(this, "Aucun résultat disponible", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(
                Intent.EXTRA_TITLE,
                "THERMOFLOOR_Rapport.pdf"
            )
        }

        startActivityForResult(intent, savePdfRequest)
    }

    private fun writePdf(uri: Uri) {
        val result = lastResult ?: return
        val document = PdfDocument()

        try {
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(230, 115, 35)
                textSize = 23f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 12f
            }

            var y = 45f
            canvas.drawText("THERMOFLOOR by ENERGICAL", 40f, y, titlePaint)
            y += 35f

            canvas.drawText("RAPPORT DE CALCUL", 40f, y, textPaint)
            y += 30f

            val lines = mutableListOf<String>()

            lines.add("Pièce : ${result.name}")
            lines.add("Disposition choisie : $selectedLayout")
            lines.add("Pertes par transmission : ${format(result.transmissionLossW)} W")
            lines.add("Pertes par ventilation : ${format(result.ventilationLossW)} W")
            lines.add("Déperditions totales : ${format(result.totalHeatLossW)} W")
            lines.add("Déperditions spécifiques : ${format(result.specificHeatLossWm2)} W/m²")
            lines.add("Puissance estimée du plancher : ${format(result.estimatedFloorOutputLimitW)} W")
            lines.add("Marge de puissance : ${format(result.outputMarginW)} W")
            lines.add("Nombre de circuits : ${result.circuitCount}")
            lines.add("")

            result.circuits.forEach { circuit ->
                lines.add("Circuit ${circuit.number}")
                lines.add("Surface : ${format(circuit.heatedAreaM2)} m²")
                lines.add("Longueur estimée : ${format(circuit.estimatedLengthM)} m")
                lines.add("Débit : ${format(circuit.flowLph)} L/h")
                lines.add("Vitesse : ${format(circuit.velocityMs)} m/s")
                lines.add("Perte de charge : ${format(circuit.pressureDropKPa)} kPa")
                lines.add("")
            }

            if (result.warnings.isNotEmpty()) {
                lines.add("AVERTISSEMENTS")
                result.warnings.forEach { lines.add("- $it") }
                lines.add("")
            }

            lines.add("NOTE : calcul préliminaire à vérifier par un professionnel.")
            lines.add("Le tracé géométrique des tubes n'est pas encore disponible.")

            for (line in lines) {
                if (y > 805f) {
                    canvas.drawText("Suite du rapport dans la version suivante.", 40f, y, textPaint)
                    break
                }
                canvas.drawText(line.take(90), 40f, y, textPaint)
                y += 19f
            }

            document.finishPage(page)

            contentResolver.openOutputStream(uri)?.use { output ->
                document.writeTo(output)
            } ?: throw IOException("Impossible d'ouvrir le fichier PDF.")

            Toast.makeText(
                this,
                "Rapport PDF enregistré",
                Toast.LENGTH_LONG
            ).show()

        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Erreur PDF : ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        } finally {
            document.close()
        }
    }

    private fun choosePdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, pickPdf)
    }

    @Deprecated("Legacy activity result API")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != Activity.RESULT_OK || data?.data == null) return

        val uri = data.data!!

        when (requestCode) {
            pickPdf -> loadPdf(uri)
            savePdfRequest -> writePdf(uri)
        }
    }

    private fun loadPdf(uri: Uri) {
        try {
            closePdf()

            pdfFileDescriptor = contentResolver.openFileDescriptor(uri, "r")
                ?: throw IOException("Impossible d'ouvrir le PDF.")

            pdfRenderer = PdfRenderer(pdfFileDescriptor!!)
            renderPage()

            Toast.makeText(
                this,
                "Plan PDF importé",
                Toast.LENGTH_SHORT
            ).show()

        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Erreur d'importation : ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun renderPage() {
        val renderer = pdfRenderer ?: return
        if (renderer.pageCount == 0) return

        val page = renderer.openPage(0)

        try {
            val maxWidth = 1800
            val maxHeight = 2400

            val scale = minOf(
                maxWidth.toFloat() / page.width,
                maxHeight.toFloat() / page.height
            )

            val width = (page.width * scale).toInt().coerceAtLeast(1)
            val height = (page.height * scale).toInt().coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
            )

            bitmap.eraseColor(Color.WHITE)
            page.render(
                bitmap,
                null,
                null,
                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
            )

            planBitmap?.recycle()
            planBitmap = bitmap
            planView.invalidate()

        } finally {
            page.close()
        }
    }

    private fun closePdf() {
        try {
            pdfRenderer?.close()
            pdfFileDescriptor?.close()
        } catch (_: Exception) {
        }

        pdfRenderer = null
        pdfFileDescriptor = null
    }

    override fun onDestroy() {
        closePdf()
        planBitmap?.recycle()
        planBitmap = null
        super.onDestroy()
    }

    private inner class PlanView : View(this@MainActivity) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var collectorX = -1f
        private var collectorY = -1f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            canvas.drawColor(Color.WHITE)

            val bitmap = planBitmap

            if (bitmap == null) {
                paint.color = Color.GRAY
                paint.textSize = 16f
                canvas.drawText(
                    "Importer un plan PDF",
                    dp(20).toFloat(),
                    height / 2f,
                    paint
                )
                return
            }

            val destination = RectF(
                0f,
                0f,
                width.toFloat(),
                height.toFloat()
            )

            val sourceRatio = bitmap.width.toFloat() / bitmap.height
            val viewRatio = width.toFloat() / height

            if (sourceRatio > viewRatio) {
                val newHeight = width / sourceRatio
                destination.top = (height - newHeight) / 2f
                destination.bottom = destination.top + newHeight
            } else {
                val newWidth = height * sourceRatio
                destination.left = (width - newWidth) / 2f
                destination.right = destination.left + newWidth
            }

            canvas.drawBitmap(bitmap, null, destination, paint)

            if (collectorX >= 0f && collectorY >= 0f) {
                paint.color = Color.RED
                paint.strokeWidth = dp(3).toFloat()

                canvas.drawCircle(
                    collectorX * width,
                    collectorY * height,
                    dp(9).toFloat(),
                    paint
                )

                canvas.drawLine(
                    collectorX * width - dp(14),
                    collectorY * height,
                    collectorX * width + dp(14),
                    collectorY * height,
                    paint
                )

                canvas.drawLine(
                    collectorX * width,
                    collectorY * height - dp(14),
                    collectorX * width,
                    collectorY * height + dp(14),
                    paint
                )
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN) {
                collectorX = (event.x / width).coerceIn(0f, 1f)
                collectorY = (event.y / height).coerceIn(0f, 1f)
                invalidate()
                return true
            }
            return true
        }

        fun clearCollector() {
            collectorX = -1f
            collectorY = -1f
            invalidate()
        }
    }
}
