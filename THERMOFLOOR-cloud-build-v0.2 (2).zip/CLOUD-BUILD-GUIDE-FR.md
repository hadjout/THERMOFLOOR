# THERMOFLOOR V0.2 — compilation cloud depuis Android

## Méthode mobile la plus simple
1. Crée un compte sur https://github.com/signup puis connecte-toi.
2. Crée un dépôt sur https://github.com/new, nomme-le `THERMOFLOOR` et choisis Private.
3. Dans le dépôt, appuie sur **Add file > Upload files** et téléverse le fichier `THERMOFLOOR-android-source-v0.2.zip` contenu dans cette archive. Valide avec **Commit changes**.
4. Crée le workflow : **Add file > Create new file**. Comme nom de fichier, saisis exactement `.github/workflows/android.yml`.
5. Copie-colle le contenu ci-dessous dans le fichier, puis **Commit changes**.
6. Ouvre l'onglet **Actions**. Le travail « Build THERMOFLOOR APK » démarre. Attends qu'il soit terminé avec une coche verte.
7. Ouvre le travail terminé et télécharge l'artefact **THERMOFLOOR-debug-apk**. C'est un ZIP contenant `app-debug.apk`.
8. Décompresse le ZIP d'artefact sur ton téléphone, ouvre `app-debug.apk`, puis autorise l'installation depuis cette source si Android le demande.

## Contenu à coller dans `.github/workflows/android.yml`

```yaml
name: Build THERMOFLOOR APK

on:
  workflow_dispatch:
  push:
    branches: [ main ]

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout source package
        uses: actions/checkout@v4

      - name: Unpack THERMOFLOOR project
        run: unzip -q THERMOFLOOR-android-source-v0.2.zip

      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android platform and build tools
        run: sdkmanager "platforms;android-35" "build-tools;35.0.0"

      - name: Build debug APK
        uses: gradle/gradle-build-action@v3
        with:
          gradle-version: '8.9'
          build-root-directory: THERMOFLOOR
          arguments: assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: THERMOFLOOR-debug-apk
          path: THERMOFLOOR/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 14
```

## Limites
Ce workflow tente de compiler un APK debug, il ne garantit pas que le code actuel compile sans correction. Si Actions affiche une croix rouge, ouvre le journal de l'étape « Build debug APK » et partage l'erreur. L'APK debug est destiné aux essais, pas à la distribution publique.

V0.2 reste un prototype : import PDF et placement du collecteur partiels ; pas encore de formulaire thermique connecté, de reconnaissance automatique des pièces, de génération automatique des boucles ni de rapport PDF. Ne pas utiliser pour dimensionner ou exécuter un chantier réel.
